# SPA binding validator

This is the main software artifact for my Liverpool University MSc Software in Engineering dissertation project

## Compilation instructions

This software can be compiled with [the scala sbt build tool](http://www.scala-sbt.org/)

Dependencies (declared in build.sbt) will be installed automatically when the system is compiled.
 
To compile the software, start sbt from the command line:

```
sbt
```

You should see output similar to this:

```
[info] Loading global plugins from /Users/steve/.sbt/0.13/plugins
[info] Loading project definition from /Users/steve/work/misc/dissertation/spabindingvalidator/project
[info] Set current project to spabindingvalidator (in build file:/Users/steve/work/misc/dissertation/spabindingvalidator/)
>
```

Indicating that sbt has loaded

Then run compile to compile the code

```
compile
```

test to run tests

```
test
```

or assembly to produce a single jar file with all dependencies bundled 

```
assembly
```

Note that test will run compile if required and assembly will run both compile and test

## Running test cases
 
Ensure that the test_spas directory is adjacent to the spabindingvalidator directory on the filesystem, then run

```
shell/all.sh
```

from the spabindingvalidator directory.

It is also possible to run the test cases individually as follows:

```
shell/angular-1.sh
shell/angular-2.sh
shell/durandal-1.sh
shell/durandal-2.sh
```

And the timing tests like so

```
shell/timing.sh
```

or to filter the output of the timing tests
 
```
shell/timing.sh |& awk '/result-line/ {print $2, $3, $4}'
```

See the comments in timing.sh for dependencies however - gtime may be required on OS X (brew install gtime if homebrew is installed on the system) and this is unlikely to work on Windows without some modification. 