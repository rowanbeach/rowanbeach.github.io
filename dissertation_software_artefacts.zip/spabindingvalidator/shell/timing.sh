#!/usr/bin/env bash

# Running this requires the gtime tool on OS X as the OS X time command does not have the necessary formatting options
# If you have homebrew installed then simply
# brew install gtime
# For linux, replacing gtime in this script with time should presumably work in the same way (untested)

# To run this and just get the useful output, run something like this in a bash command line:
# shell/timing.sh |& awk '/result-line/ {print $2, $3, $4}'
# This is the command that was used to collect the timing data for the results

iterations=10

for i in `seq 1 ${iterations}`;
do
    echo "*** Running angular-1 iteration $i ***"
    gtime -f "result-line %e %M %C" $(dirname "${BASH_SOURCE}")/angular-1.sh
done

for i in `seq 1 ${iterations}`;
do
    echo "*** Running angular-1 iteration $i ***"
    gtime -f "result-line %e %M %C" $(dirname "${BASH_SOURCE}")/angular-2.sh
done

for i in `seq 1 ${iterations}`;
do
    echo "*** Running angular-1 iteration $i ***"
    gtime -f "result-line %e %M %C" $(dirname "${BASH_SOURCE}")/durandal-1.sh
done

for i in `seq 1 ${iterations}`;
do
    echo "*** Running angular-1 iteration $i ***"
    gtime -f "result-line %e %M %C" $(dirname "${BASH_SOURCE}")/durandal-2.sh
done

