#!/usr/bin/env bash

echo "*** Running angular-1 ***"
$(dirname "${BASH_SOURCE}")/angular-1.sh

echo "*** Running angular-2 ***"
$(dirname "${BASH_SOURCE}")/angular-2.sh

echo "*** Running durandal-1 ***"
$(dirname "${BASH_SOURCE}")/durandal-1.sh

echo "*** Running durandal-2 ***"
$(dirname "${BASH_SOURCE}")/durandal-2.sh

