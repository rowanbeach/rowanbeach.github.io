#!/usr/bin/env bash

p="$(dirname "${BASH_SOURCE}")"
tsp="$p/../../test_spas"

java -Dcom.rowanbeach.spabindingvalidator.rootPath="$tsp/angular-2/" -Dcom.rowanbeach.spabindingvalidator.viewModelFilenamePath="$tsp/angular-2/viewmodels/" -Dcom.rowanbeach.spabindingvalidator.viewModelFilenameStrategy=a -Dcom.rowanbeach.spabindingvalidator.viewFilenamePath="$tsp/angular-2/views/" -Dcom.rowanbeach.spabindingvalidator.viewFilenameStrategy=a -Dcom.rowanbeach.spabindingvalidator.spaType=a -Dcom.rowanbeach.spabindingvalidator.viewModelIgnoreBindingRoot=viewmodel -Dcom.rowanbeach.spabindingvalidator.viewModelNamespacePrefix=angulartest.viewmodels -jar "$p/../target/scala-2.11/spabindingvalidator-assembly-1.0.jar"
