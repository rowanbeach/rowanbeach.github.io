#!/usr/bin/env bash

p="$(dirname "${BASH_SOURCE}")"
tsp="$p/../../test_spas"

java -Dcom.rowanbeach.spabindingvalidator.rootPath="$tsp/durandal-2/" -Dcom.rowanbeach.spabindingvalidator.viewModelFilenamePath="$tsp/durandal-2/viewmodels/" -Dcom.rowanbeach.spabindingvalidator.viewModelFilenameStrategy=a -Dcom.rowanbeach.spabindingvalidator.viewFilenamePath="$tsp/durandal-2/views/" -Dcom.rowanbeach.spabindingvalidator.viewFilenameStrategy=a -Dcom.rowanbeach.spabindingvalidator.spaType=d -Dcom.rowanbeach.spabindingvalidator.viewModelNamespacePrefix=durandaltest.viewmodels -Dorg.slf4j.simpleLogger.defaultLogLevel=error -jar "$p/../target/scala-2.11/spabindingvalidator-assembly-1.0.jar"

