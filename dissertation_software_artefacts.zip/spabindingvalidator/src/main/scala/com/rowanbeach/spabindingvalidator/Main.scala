package com.rowanbeach.spabindingvalidator

import com.rowanbeach.spabindingvalidator.bindingmarkup.spaframeworks.angularjs.AngularJSParsingStrategy
import com.rowanbeach.spabindingvalidator.bindingmarkup.spaframeworks.durandal.DurandalParsingStrategy
import com.rowanbeach.spabindingvalidator.common._
import com.rowanbeach.spabindingvalidator.typescript.spaframeworks.durandal.DurandalTypeScriptSignatureParser
import com.rowanbeach.spabindingvalidator.typescript.{StandardTypeScriptTypeSignatureParser, viewModelFileStrategies}

object Main {

  def main(args: Array[String]): Unit = {
    SpaBindingValidatorRunner.run(JavaPropertiesBasedSpaBindingValidatorConfiguration)
  }

  lazy val angularTest1Config = SimpleSpaBindingValidatorConfiguration(
    rootPath = "/Users/steve/work/misc/dissertation/test_spas/angular-1/app/scripts/",
    viewModelFilenames = viewModelFileStrategies.allFilesInDirectory("/Users/steve/work/misc/dissertation/test_spas/angular-1/app/scripts/angulartest/viewmodels/"),
    viewFiles = viewFileStrategies.allFilesInDirectory("/Users/steve/work/misc/dissertation/test_spas/angular-1/app/views"),
    typeScriptTypeSignatureParser = StandardTypeScriptTypeSignatureParser,
    spaParsingStrategy = AngularJSParsingStrategy,
    viewModelPartitioningStrategy = ViewModelPartitioningStrategies.accessorPartitioner("viewmodel"),
    viewModelNameResolutionStrategy = ViewModelNameResolutionStrategies.interfaceNameMatchingStrategy("angulartest.viewmodels")
  )

  lazy val angularTest2Config = SimpleSpaBindingValidatorConfiguration(
    rootPath = "/Users/steve/work/misc/dissertation/test_spas/angular-2/",
    viewModelFilenames = viewModelFileStrategies.allFilesInDirectory("/Users/steve/work/misc/dissertation/test_spas/angular-2/viewmodels/"),
    viewFiles = viewFileStrategies.allFilesInDirectory("/Users/steve/work/misc/dissertation/test_spas/angular-2/views/"),
    typeScriptTypeSignatureParser = StandardTypeScriptTypeSignatureParser,
    spaParsingStrategy = AngularJSParsingStrategy,
    viewModelPartitioningStrategy = ViewModelPartitioningStrategies.accessorPartitioner("viewmodel"),
    viewModelNameResolutionStrategy = ViewModelNameResolutionStrategies.interfaceNameMatchingStrategy("angulartest.viewmodels")
  )

  lazy val durandalTest1Config = SimpleSpaBindingValidatorConfiguration(
    rootPath = "/Users/steve/work/misc/dissertation/test_spas/durandal-1/app/",
    viewModelFilenames = viewModelFileStrategies.allFilesInDirectory("/Users/steve/work/misc/dissertation/test_spas/durandal-1/app/viewmodels/"),
    viewFiles = viewFileStrategies.allFilesInDirectory("/Users/steve/work/misc/dissertation/test_spas/durandal-1/app/views"),
    typeScriptTypeSignatureParser = DurandalTypeScriptSignatureParser,
    spaParsingStrategy = DurandalParsingStrategy,
    viewModelPartitioningStrategy = ViewModelPartitioningStrategies.identityPartitioner,
    viewModelNameResolutionStrategy = ViewModelNameResolutionStrategies.interfaceNameMatchingStrategy("durandaltest.viewmodels")
  )

}
