package com.rowanbeach.spabindingvalidator.typescript.spaframeworks.durandal

import com.rowanbeach.spabindingvalidator.typescript._

object DurandalTypeScriptSignatureParser extends TypeScriptTypeSignatureParser {

  override def parse(typeName: String, containerNamespace: String): TypeScriptType = {
    val base = StandardTypeScriptTypeSignatureParser.parse(typeName, containerNamespace)
    base match {
      case r: TypeScriptSimpleTypeRef if r.typeName.toLowerCase.contains("observable") && r.typeParameters.length == 1 => r.typeParameters.head
      case o => o
    }
  }

  override def parseTypeParameterNamesForComplexType(typeName: String): List[TypeScriptTypeParameterPlaceholder] = StandardTypeScriptTypeSignatureParser.parseTypeParameterNamesForComplexType(typeName)
}
