package com.rowanbeach.spabindingvalidator.bindingmarkup

import org.jsoup.nodes._

import scala.collection.JavaConversions._

object MarkupTreeBuilder {

  def buildMarkupTree(markup: String): MarkupNode = {

    val htmlDoc = org.jsoup.Jsoup.parse(markup).body()

    def htmlNodeToMarkupNode(node: Node): MarkupNode = {
      node match {
        case textNode: TextNode => TextMarkupNode(textNode, textNode.childNodes().toList.map(x => htmlNodeToMarkupNode(x)))
        case element: Element => ElementMarkupNode(element, element.childNodes().toList.map(x => htmlNodeToMarkupNode(x)))
        case comment: Comment => CommentMarkupNode(comment, comment.childNodes().toList.map(x => htmlNodeToMarkupNode(x)))
      }
    }

    val x = htmlNodeToMarkupNode(htmlDoc)
    x

  }

}
