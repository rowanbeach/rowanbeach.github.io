package com.rowanbeach.spabindingvalidator.common

import com.rowanbeach.spabindingvalidator.bindingmarkup.BindingMarkupCommonASTBuilder
import com.rowanbeach.spabindingvalidator.common.ASTModelComparisonResults.{FoundASTModelComparisonResult, NotFoundASTModelComparisonResult}
import com.rowanbeach.spabindingvalidator.typescript.TypeScriptCommonASTBuilder
import com.typesafe.scalalogging.LazyLogging

object SpaBindingValidatorRunner extends LazyLogging {

  /**
   * runs the binding validation with the given configuration
   * @return true if all bindings are successfully validated (even if warnings are generated), false if any binding failures are found
   */
  def run(conf: SpaBindingValidatorConfiguration): Boolean = {

    val commonASTFromTypeScript: Map[String, CommonASTMemberContainer] = TypeScriptCommonASTBuilder.buildSyntaxTrees(conf.rootPath, conf.viewModelFilenames, conf.typeScriptTypeSignatureParser)

    val commonASTsFromHTMLBindings = BindingMarkupCommonASTBuilder.buildSyntaxTrees(conf.viewFiles, conf.spaParsingStrategy)

    val results = commonASTsFromHTMLBindings.map({
      case (markupHTMLName, markupHTMLModel) =>

        logger.debug(MemberContainerHierarchyFormatter.treeDisplay(CommonASTTypeContainer(commonASTsFromHTMLBindings)))

        val dottedResolvedViewModelName = conf.viewModelNameResolutionStrategy(markupHTMLName)
        val viewModel = commonASTFromTypeScript.get(dottedResolvedViewModelName)

        viewModel match {
          case Some(vm) =>

            conf.viewModelPartitioningStrategy(markupHTMLModel) match {
              case (ViewModelPartitioningResult(None, _)) => NotFoundASTModelComparisonResult(markupHTMLName, dottedResolvedViewModelName)
              case (ViewModelPartitioningResult(Some(markupModelToMatch), modelsOutsideBindingRoot)) =>
                val viewToModelMatchingContainer = SyntaxTreeComparer.compareViewToModel(markupModelToMatch, vm)
                val modelToViewMatchingContainer = SyntaxTreeComparer.compareModelToView(vm, markupModelToMatch)
                FoundASTModelComparisonResult(markupHTMLName, dottedResolvedViewModelName, viewToModelMatchingContainer, modelToViewMatchingContainer, modelsOutsideBindingRoot)
            }

          case None => NotFoundASTModelComparisonResult(markupHTMLName, dottedResolvedViewModelName)
        }

    })

    def indent(s:String) : String = s.replaceAll("(?m)^", "\t")

    def printIfAny(instances: Map[String, ASTNodeComparisonResult], message: String): Unit = {
      if (instances.nonEmpty) {
        println(s"\t$message")
        println(indent(MemberContainerHierarchyFormatter.treeDisplay(ASTMatchingContainer(null, null, instances))))
      }
    }

    results.toList.sortBy(_.viewPath).foreach({

      case f: FoundASTModelComparisonResult =>
        println(f)
        println()

        printIfAny(f.viewToModelMatchingFailures, "view -> model matching failures")
        printIfAny(f.viewToModelMatchingWarnings, "view -> model matching warnings")
        printIfAny(f.modelToViewMatchingFailures, "model -> view matching failures")
        printIfAny(f.modelToViewMatchingWarnings, "model -> view matching warnings")
 
        if (f.modelsOutsideRoot.nonEmpty) {
          println("\tThe following were found outside the binding root for this view model")
          f.modelsOutsideRoot.foreach(x => println(x.toString().replaceAll("(?m)^", "\t")))
        }
      case nf: NotFoundASTModelComparisonResult => println(nf)

    })

    // Return 1 or 0 from main for command line interoperability
    results.exists(!_.isSuccessful)

  }

}
