package com.rowanbeach.spabindingvalidator.common

import com.rowanbeach.spabindingvalidator.bindingmarkup.SpaParsingStrategy
import com.rowanbeach.spabindingvalidator.typescript.TypeScriptTypeSignatureParser

/**
 * Represents a set of configuration for the spa binding validator
 */
trait SpaBindingValidatorConfiguration {
  val rootPath: String
  val viewModelFilenames: List[String]
  val viewFiles: List[(String, String)]
  val typeScriptTypeSignatureParser: TypeScriptTypeSignatureParser
  val spaParsingStrategy: SpaParsingStrategy
  val viewModelPartitioningStrategy: CommonASTMemberContainer => ViewModelPartitioningResult
  val viewModelNameResolutionStrategy: String => String
}
