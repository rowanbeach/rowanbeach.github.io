package com.rowanbeach.spabindingvalidator.bindingmarkup

object BindingListBuilder {

  def buildBindingList(markup: String, spaParsingStrategy: SpaParsingStrategy): List[HTMLBinding] = {
    val rootNode = MarkupTreeBuilder.buildMarkupTree(markup)
    spaParsingStrategy.parseMarkupTree(rootNode)
  }

}
