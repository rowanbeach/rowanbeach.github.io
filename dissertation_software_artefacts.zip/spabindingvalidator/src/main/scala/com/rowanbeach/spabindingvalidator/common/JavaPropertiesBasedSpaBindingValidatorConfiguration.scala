package com.rowanbeach.spabindingvalidator.common

import com.github.kxbmap.configs._
import com.rowanbeach.spabindingvalidator.bindingmarkup.spaframeworks.angularjs.AngularJSParsingStrategy
import com.rowanbeach.spabindingvalidator.bindingmarkup.spaframeworks.durandal.DurandalParsingStrategy
import com.rowanbeach.spabindingvalidator.common.SupportedSpaType.SupportedSpaType
import com.rowanbeach.spabindingvalidator.typescript.spaframeworks.durandal.DurandalTypeScriptSignatureParser
import com.rowanbeach.spabindingvalidator.typescript.{StandardTypeScriptTypeSignatureParser, viewModelFileStrategies}
import com.typesafe.config.ConfigException.BadValue
import com.typesafe.config.ConfigFactory

/**
 * A java properties based implementation of SpaBindingValidatorConfiguration
 */
object JavaPropertiesBasedSpaBindingValidatorConfiguration extends SpaBindingValidatorConfiguration {

  private val config = ConfigFactory.load()

  val rootPath = config.get[String]("com.rowanbeach.spabindingvalidator.rootPath")

  private lazy val viewModelFilenamePath = config.get[String]("com.rowanbeach.spabindingvalidator.viewModelFilenamePath")

  val viewModelFilenames: List[String] = config.get[String]("com.rowanbeach.spabindingvalidator.viewModelFilenameStrategy") match {
    case "a" => viewModelFileStrategies.allFilesInDirectory(viewModelFilenamePath)
    case "s" => viewModelFileStrategies.singleFile(viewModelFilenamePath)
    case _ => throw new BadValue("com.rowanbeach.spabindingvalidator.viewModelFilenameStrategy", """viewModelFileNameStrategy should be one of a or s""")
  }

  private lazy val viewFilenamePath = config.get[String]("com.rowanbeach.spabindingvalidator.viewFilenamePath")

  val viewFiles: List[(String, String)] = config.get[String]("com.rowanbeach.spabindingvalidator.viewFilenameStrategy") match {
    case "a" => viewFileStrategies.allFilesInDirectory(viewFilenamePath)
    case "s" => viewFileStrategies.singleFile(viewFilenamePath)
    case _ => throw new BadValue("com.rowanbeach.spabindingvalidator.viewFilenameStrategy", """viewFilenameStrategy should be one of a or s""")
  }

  val spaType: SupportedSpaType = config.get[String]("com.rowanbeach.spabindingvalidator.spaType") match {
    case "a" => SupportedSpaType.AngularJS
    case "d" => SupportedSpaType.Durandal
    case _ => throw new BadValue("com.rowanbeach.spabindingvalidator.spaType", """spaType should be one of a or d""")
  }

  val typeScriptTypeSignatureParser = spaType match {
    case SupportedSpaType.Durandal => DurandalTypeScriptSignatureParser
    case _ => StandardTypeScriptTypeSignatureParser
  }

  val spaParsingStrategy = spaType match {
    case SupportedSpaType.Durandal => DurandalParsingStrategy
    case SupportedSpaType.AngularJS => AngularJSParsingStrategy
  }

  val viewModelPartitioningStrategy: (CommonASTMemberContainer) => ViewModelPartitioningResult = config.get[Option[String]]("com.rowanbeach.spabindingvalidator.viewModelIgnoreBindingRoot") match {
    case Some(viewModelIgnoreBindingRoot) => ViewModelPartitioningStrategies.accessorPartitioner(viewModelIgnoreBindingRoot)
    case _ => ViewModelPartitioningStrategies.identityPartitioner
  }

  val viewModelNameResolutionStrategy: (String) => String = ViewModelNameResolutionStrategies.interfaceNameMatchingStrategy(config.get[String]("com.rowanbeach.spabindingvalidator.viewModelNamespacePrefix"))

}
