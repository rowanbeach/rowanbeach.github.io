package com.rowanbeach.spabindingvalidator.common

object ASTModelComparisonResults {

  trait ASTModelComparisonResult {
    val isSuccessful: Boolean
    val hasWarnings: Boolean
    val viewPath: String
  }

  case class FoundASTModelComparisonResult(viewPath: String, viewModelName: String, viewToModelMatchingContainer: ASTMatchingContainer, modelToViewMatchingContainer: ASTMatchingContainer, modelsOutsideRoot: List[(String, CommonASTType)] = Nil) extends ASTModelComparisonResult {

    trait ASTNodeComparisonResultExtractor {
      def unapply(member: (String, ASTNodeComparisonResult)): Option[(String, ASTNodeComparisonResult)]
    }

    object WarningExtractor extends ASTNodeComparisonResultExtractor {
      def unapply(member: (String, ASTNodeComparisonResult)): Option[(String, ASTNodeComparisonWarning)] = member match {
        case (name, c: ASTNodeComparisonWarning) => Some(name, c)
        case _ => None
      }
    }

    object FailureExtractor extends ASTNodeComparisonResultExtractor {
      def unapply(member: (String, ASTNodeComparisonResult)): Option[(String, ASTNodeComparisonFailure)] = member match {
        case (name, c: ASTNodeComparisonFailure) => Some(name, c)
        case _ => None
      }
    }

    def collectResultsAsTree(members: Map[String, ASTNodeComparisonResult], comparisonResultExtractor: ASTNodeComparisonResultExtractor): Map[String, ASTNodeComparisonResult] = {
      members.flatMap {
//                case (name, c: ASTMatchingContainer) if anyMemberContainsWarningOrFailure(c.members) => (name, c.copy(members = collectWarningsAndFailures(c.members)))
        case (name, c: ASTMatchingContainer) =>
          val innerResults = collectResultsAsTree(c.members, comparisonResultExtractor)
          if (innerResults.isEmpty) None else Some((name, c.copy(members = collectResultsAsTree(c.members, comparisonResultExtractor))))
//        case (name, c: ASTNodeComparisonFailure) => Some((name, c))
//        case (name, c: ASTNodeComparisonWarning) => Some((name, c))
        case comparisonResultExtractor((name, c)) => Some((name : String, c : ASTNodeComparisonResult))
        case _ => None
      }
    }

    val viewToModelMatchingFailures = collectResultsAsTree(viewToModelMatchingContainer.members, FailureExtractor)
    val viewToModelMatchingWarnings = collectResultsAsTree(viewToModelMatchingContainer.members, WarningExtractor)

    val modelToViewMatchingFailures = collectResultsAsTree(modelToViewMatchingContainer.members, FailureExtractor)
    val modelToViewMatchingWarnings = collectResultsAsTree(modelToViewMatchingContainer.members, WarningExtractor)

    val isSuccessful = modelsOutsideRoot.isEmpty && viewToModelMatchingFailures.isEmpty && modelToViewMatchingFailures.isEmpty
    val hasWarnings = modelToViewMatchingWarnings.nonEmpty || viewToModelMatchingWarnings.nonEmpty

    override val toString = s"""${if (isSuccessful) "SUCCESS" else "FAILURE"}: $viewModelName => $viewPath"""

  }

  case class NotFoundASTModelComparisonResult(viewPath: String, viewModelName: String) extends ASTModelComparisonResult {

    val isSuccessful = false
    val hasWarnings = false

    override val toString = s"FAILURE: Unable to find viewmodel $viewModelName for view $viewPath"

    val failures: Map[String, ASTNodeComparisonResult] = Map()

  }

}
