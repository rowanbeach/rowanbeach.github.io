package com.rowanbeach.spabindingvalidator.typescript

import com.rowanbeach.spabindingvalidator.common.{CommonASTTypeContainer, CommonASTMemberContainer, MemberContainerHierarchyFormatter}
import com.typesafe.scalalogging.LazyLogging

/**
 * This is a facade which wraps the process of building the TypeScript common AST model
 */
object TypeScriptCommonASTBuilder extends LazyLogging {

  def buildSyntaxTrees(rootPath: String, viewModelFiles: List[String], typeScriptTypeSignatureParser: TypeScriptTypeSignatureParser): Map[String, CommonASTMemberContainer] = {

    val memberMap: Map[String, TypeScriptComplexType] = TypeScriptMemberMapBuilder.build(rootPath, viewModelFiles, typeScriptTypeSignatureParser) // One entry per file

    logger.debug("*** memberMap ***")

    memberMap.toList.sortBy(x => x._1).foreach({ case (key, t) =>
      logger.debug(s"memberMap for: $key ($t)")
      logger.debug(s"\n${MemberContainerHierarchyFormatter.treeDisplay(t)}")
    })

    val typeScriptComplexTypes: Map[String, TypeScriptComplexType] = TypeScriptComplexTypeBuilder.buildFrom(memberMap)

    logger.debug("\n*** typeScriptComplexTypes ***")
    logger.debug(s"\n${MemberContainerHierarchyFormatter.treeDisplay(TypeScriptModule(typeScriptComplexTypes))}")

    val commonASTModelFromTypeScript = TypeScriptCommonASTModelMapper.mapComplexTypes(typeScriptComplexTypes)

    logger.debug("\n*** commonASTModelFromTypeScript ***")
    logger.debug(s"\n${MemberContainerHierarchyFormatter.treeDisplay(CommonASTTypeContainer(commonASTModelFromTypeScript))}")

    commonASTModelFromTypeScript

  }

}
