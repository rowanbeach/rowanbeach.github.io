package com.rowanbeach.spabindingvalidator.bindingmarkup

import com.rowanbeach.spabindingvalidator.common.CommonASTMemberContainer
import com.typesafe.scalalogging.LazyLogging

/**
 * Builds the AST for a single markup node
 * Typically the markup passed into this function will represent the content of a single HTML file
 */
object BindingMarkupNodeCommonASTBuilder extends LazyLogging {

  def buildSyntaxTree(markup: String, spaParsingStrategy: SpaParsingStrategy): CommonASTMemberContainer = {
    val flatMarkupASTModel = BindingListBuilder.buildBindingList(markup, spaParsingStrategy)
    logger.debug(s"flatMarkupASTModel: $flatMarkupASTModel")
    val commonASTModel = HTMLBindingsToCommonASTTransformer.transform(flatMarkupASTModel)
    logger.debug(s"commonASTModel: $commonASTModel")
    commonASTModel
  }

}
