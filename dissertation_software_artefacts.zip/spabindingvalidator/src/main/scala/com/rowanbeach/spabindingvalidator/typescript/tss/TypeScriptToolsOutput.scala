package com.rowanbeach.spabindingvalidator.typescript.tss

import java.io.{BufferedReader, PrintWriter}

import com.typesafe.scalalogging.LazyLogging
import org.json4s.DefaultFormats
import org.json4s.jackson.JsonMethods

object OutputRegexes {
  val syntaxError = "\"TSS command syntax error: (.*)\"".r
}

class TypeScriptToolsInput(val writer: PrintWriter) extends LazyLogging {

  def writeLine(line: String): Unit = {
    logger.debug(line)
    writer.write(line)
    writer.write("\n")
    writer.flush()
  }

}

class TypeScriptToolsOutput(val reader: BufferedReader) {

  implicit val formats = DefaultFormats // JSON serialiser configuration

  def readStringLine(): String = {
    this.reader.readLine() match {
      case OutputRegexes.syntaxError(errorText) => throw new Error(errorText)
      case json => JsonMethods.parse(json).extract[String]
    }
  }

  def readStructureLine(): List[TypeScriptMetadataStructure] = {
    this.reader.readLine() match {
      case OutputRegexes.syntaxError(errorText) => throw new Error(errorText)
      case json => JsonMethods.parse(json).extract[List[TypeScriptMetadataStructure]]
    }
  }

  def readDefinitionLine(): TypeScriptMetadataDefinition = {
    this.reader.readLine() match {
      case OutputRegexes.syntaxError(errorText) => throw new Error(errorText)
      case json => JsonMethods.parse(json).extract[TypeScriptMetadataDefinition]
    }
  }

  def readTypeLine(): TypeScriptMetadataType = {
    this.reader.readLine() match {
      case OutputRegexes.syntaxError(errorText) => throw new Error(errorText)
      case json => JsonMethods.parse(json).extract[TypeScriptMetadataType]
    }
  }

  def readFilesLine(): List[String] = {
    this.reader.readLine() match {
      case OutputRegexes.syntaxError(errorText) => throw new Error(errorText)
      case json => JsonMethods.parse(json).extract[List[String]]
    }
  }

}

case class FilePosition(line: Int, character: Int)

case class TypeScriptLoc(name: String, kind: String, kindModifiers: String, matchKind: String, fileName: String, minChar: Int, limChar: Int, additionalSpans: Any, containerName: String, containerKind: String)

case class TypeScriptMetadataStructure(loc: TypeScriptLoc, file: String, min: FilePosition, lim: FilePosition)

case class TypeScriptDef(fileName: String, minChar: Int, limChar: Int, kind: String, name: String, containerKind: String, containerName: String)

case class TypeScriptMetadataDefinition(`def`: TypeScriptDef, file: String, min: FilePosition, lim: FilePosition)

case class TypeScriptMetadataType(kind: String, `type`: String, fullSymbolName: String)

