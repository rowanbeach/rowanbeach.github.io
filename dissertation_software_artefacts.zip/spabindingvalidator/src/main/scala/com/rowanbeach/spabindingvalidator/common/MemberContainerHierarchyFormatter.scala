package com.rowanbeach.spabindingvalidator.common

object MemberContainerHierarchyFormatter {

  private val lineSeparator: String = System.getProperty("line.separator")

  /**
   * A utility function to format types which implement the MemberContainer trait into an ASCII tree for display
   */
  def treeDisplay(container: MemberContainer) : String = {

    val sb = new StringBuilder()

    /**
     * This defines a recursive function which is called for each level in each branch of a tree
     */
    def innerTree(container: MemberContainer, levels: List[Boolean]): Unit = {

      case class Member(name: String, memberType: Any)

      val members = container.members.map({
        case (name, value) => new Member(name, value)
      }).toList

      for ((m, i) <- members.zipWithIndex.sortBy(x => x._2)) {
        for (level <- levels) sb.append(if (level) "│   " else "    ")
        val lastOrPast = i > members.length - 2
        sb.append(s"${if (lastOrPast) "└──" else "├──"} ${m.name}: ${m.memberType}")
        sb.append(lineSeparator)
        m.memberType match {
          case c: MemberContainer => innerTree(c, levels :+ !lastOrPast)
          case _ =>
        }
      }
    }

    innerTree(container, Nil)

    sb.toString()

  }

}
