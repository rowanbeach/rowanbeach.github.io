package com.rowanbeach.spabindingvalidator.bindingmarkup

import com.rowanbeach.spabindingvalidator.common.{MemberContainerHierarchyFormatter, CommonASTMemberContainer}
import com.typesafe.scalalogging.LazyLogging

/**
 * Builds the AST for multiple named markup nodes (typically each node represents a different HTML file
 * This uses BindingMarkupNodeCommonASTBuilder to build each individual AST
 */
object BindingMarkupCommonASTBuilder extends LazyLogging {

  def buildSyntaxTrees(viewFiles: List[(String, String)], spaParsingStrategy: SpaParsingStrategy): Map[String, CommonASTMemberContainer] = {
    val viewNamesAndMarkup = viewFiles
    val rootMarkupNodes = viewNamesAndMarkup.map({ case (name, markup) => (name, BindingMarkupNodeCommonASTBuilder.buildSyntaxTree(markup, spaParsingStrategy))})

    rootMarkupNodes.foreach{case (key, value) =>
      logger.debug(key)
      logger.debug(MemberContainerHierarchyFormatter.treeDisplay(value))
    }

    rootMarkupNodes.toMap
  }

}

