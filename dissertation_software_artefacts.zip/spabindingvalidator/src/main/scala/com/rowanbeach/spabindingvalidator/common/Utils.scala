package com.rowanbeach.spabindingvalidator.common

object Utils {

  def concatenateNamespaceElements(namespaceElements: String*): String = {
    namespaceElements.filterNot(_.isEmpty).mkString(".")
  }

  def stripLastElementOfDottedName(dottedName: String): String = {
    dottedName.lastIndexOf('.') match {
      case -1 => ""
      case index => dottedName.substring(0, index)
    }
  }

  val namespaceFromFullyQualifiedName: String => String = stripLastElementOfDottedName

}
