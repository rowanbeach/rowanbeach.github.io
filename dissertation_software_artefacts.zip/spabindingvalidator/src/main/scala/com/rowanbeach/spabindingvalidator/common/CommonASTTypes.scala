package com.rowanbeach.spabindingvalidator.common

trait CommonASTType

trait CommonASTLeafNode extends CommonASTType

trait CommonASTPrimitiveType extends CommonASTLeafNode

case object CommonASTBoolean extends CommonASTPrimitiveType {
  override val toString = "boolean"
}

case object CommonASTDate extends CommonASTPrimitiveType {
  override val toString = "Date"
}

case object CommonASTNumber extends CommonASTPrimitiveType {
  override val toString = "number"
}

case object CommonASTString extends CommonASTPrimitiveType {
  override val toString = "string"
}

case object CommonASTAny extends CommonASTPrimitiveType {
  override val toString = "any"
}

case object CommonASTBooleanArray extends CommonASTPrimitiveType {
  override val toString = "boolean[]"
}

case object CommonASTDateArray extends CommonASTPrimitiveType {
  override val toString = "Date[]"
}

case object CommonASTNumberArray extends CommonASTPrimitiveType {
  override val toString = "number[]"
}

case object CommonASTStringArray extends CommonASTPrimitiveType {
  override val toString = "string[]"
}

case object CommonASTAnyArray extends CommonASTPrimitiveType {
  override val toString = "any[]"
}

case class CommonASTFunction(returnType: CommonASTType) extends CommonASTLeafNode {
  override val toString = s"() => $returnType"
}

case class CommonASTUnknownType(n: String) extends CommonASTType {
  override val toString = s"unknown type ($n)"
}

case class CommonASTUnknownPrimitiveType(n: String) extends CommonASTPrimitiveType {
  override val toString = s"unknown primitive type ($n)"
}

case object CommonASTVoid extends CommonASTPrimitiveType {
  override val toString = "void"
}

trait CommonASTMemberContainer extends CommonASTType with MemberContainer {

  val members: Map[String, CommonASTType]

  def apply(name: String): Option[CommonASTType] = members.get(name)

  def getChildContainer(name: String): Option[CommonASTMemberContainer] = {
    apply(name) match {
      case Some(x) => x match {
        case y: CommonASTMemberContainer => Some(y)
        case _ => None
      }
      case _ => None
    }
  }

  def getNestedContainer(path: List[String]): Option[CommonASTMemberContainer] = {
    path.foldLeft(Some(this): Option[CommonASTMemberContainer])((container, x) => container.flatMap(c => c.getChildContainer(x)))
  }

}

case class CommonASTTypeContainer(members: Map[String, CommonASTType]) extends CommonASTMemberContainer {

  override val toString = {
    s"container (${members.keys.mkString(",")})"
  }

}

case class CommonASTTypeContainerArray(members: Map[String, CommonASTType]) extends CommonASTMemberContainer {

  override val toString = {
    s"container[] (${members.keys.mkString(",")})"
  }

}



