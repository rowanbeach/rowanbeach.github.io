package com.rowanbeach.spabindingvalidator.common

import com.rowanbeach.spabindingvalidator.bindingmarkup.SpaParsingStrategy
import com.rowanbeach.spabindingvalidator.typescript.TypeScriptTypeSignatureParser

/**
 * A simple case class based implementation of SpaBindingValidatorConfiguration
 */
case class SimpleSpaBindingValidatorConfiguration(
             rootPath: String,
             viewModelFilenames: List[String],
             viewFiles: List[(String, String)],
             typeScriptTypeSignatureParser: TypeScriptTypeSignatureParser,
             spaParsingStrategy: SpaParsingStrategy,
             viewModelPartitioningStrategy: CommonASTMemberContainer => ViewModelPartitioningResult,
             viewModelNameResolutionStrategy: String => String) extends SpaBindingValidatorConfiguration


