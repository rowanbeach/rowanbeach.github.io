package com.rowanbeach.spabindingvalidator.typescript

import com.rowanbeach.spabindingvalidator.common.Utils
import com.rowanbeach.spabindingvalidator.typescript.tss.{TSSInterface, TypeScriptMetadataStructure}
import com.typesafe.scalalogging.LazyLogging

object TypeScriptMemberMapBuilder extends LazyLogging {

  def build(rootPath: String, viewModelFilenames: List[String], typeScriptTypeSignatureParser: TypeScriptTypeSignatureParser): Map[String, TypeScriptComplexType] = {

    case class FlatTypeScriptStructure(name: String, containerName: String, kind: String, typeName: String)

    val tssInterface = new TSSInterface(rootPath, viewModelFilenames)

    def getTypeNameFor(structure: TypeScriptMetadataStructure): String = {

      logger.debug(s"getTypeNameFor:${structure.loc.kind} - ${structure.loc.name} - ${structure.loc.kindModifiers}")

      // The tss command line output incorrectly defines the start location of class / interface definitions so this is a workaround for that
      val fixedMin = structure.loc.kind match {
        case "class" | "interface" => structure.loc.kindModifiers match {
          case "export" => structure.min.copy(character = structure.min.character + "export".length + structure.loc.kind.length + 2)
          case _ => structure.min.copy(character = structure.min.character + structure.loc.kind.length + 1)
        }
        case _ => structure.min
      }

      tssInterface.typeInfo(fixedMin.line, fixedMin.character, structure.file).`type`

    }

    // 0 - get a full list of referenced filenames from tss
    val referencedTypeScriptFiles = tssInterface.files
    logger.debug(s"referencedTypeScriptFiles $referencedTypeScriptFiles")

    // 1 - get structure definitions from tss and flatten all required values
    val flatStructures = referencedTypeScriptFiles
      .flatMap(tssInterface.fileStructure)
      .map(x => FlatTypeScriptStructure(x.loc.name, x.loc.containerName, x.loc.kind, if (x.loc.kind == "property" || x.loc.kind == "interface" || x.loc.kind == "class") getTypeNameFor(x) else null))

    flatStructures.foreach(x => logger.debug(x.toString))

    def replaceRefsWithParameterRefs(typeScriptType: TypeScriptType, typeScriptTypeParameterPlaceholders: List[TypeScriptTypeParameterPlaceholder]): TypeScriptType = {
      logger.debug(s"replaceRefsWithParameterRefs for $typeScriptType with $typeScriptTypeParameterPlaceholders")
      val result = typeScriptType match {
        // TODO - array mapping here for refs?
        case rp: TypeScriptTypeRef if rp.typeParameters.nonEmpty => rp.withTypeParameters(typeParameters = rp.typeParameters.map(x => replaceRefsWithParameterRefs(x, typeScriptTypeParameterPlaceholders)))
        case r: TypeScriptTypeRef if typeScriptTypeParameterPlaceholders.exists(x => x.slotName == r.typeName) => r match {
          case _: TypeScriptArrayTypeRef => TypeScriptArrayTypeParameterRef(r.typeName)
          case _ => TypeScriptSimpleTypeParameterRef(r.typeName)
        }
        case other => other
      }
      logger.debug(s"replaceRefsWithParameterRefs returning $result for $typeScriptType with $typeScriptTypeParameterPlaceholders")
      result
    }

    // Map classes and interfaces with their members
    val mappedStructures = flatStructures collect {
      case s: FlatTypeScriptStructure if s.kind == "interface" || s.kind == "class" =>
        val fullyQualifiedName = Utils.concatenateNamespaceElements(s.containerName, s.name)
        fullyQualifiedName -> (typeScriptTypeSignatureParser.parseTypeParameterNamesForComplexType(s.typeName) match {
          case Nil => TypeScriptNonGenericType(flatStructures.filter(_.containerName.startsWith(fullyQualifiedName)).collect({
            case x if x.kind == "property" => x.name -> typeScriptTypeSignatureParser.parse(x.typeName, s.containerName)
            case x if x.kind == "method" => x.name -> TypeScriptFunction(TypeScriptVoid)
          }).toMap)
          case typeParameterPlaceholders => TypeScriptGenericType(typeParameterPlaceholders, flatStructures.filter(_.containerName.startsWith(fullyQualifiedName)).collect({
            case x if x.kind == "property" => x.name -> replaceRefsWithParameterRefs(typeScriptTypeSignatureParser.parse(x.typeName, s.containerName), typeParameterPlaceholders)
            case x if x.kind == "method" => x.name -> TypeScriptFunction(TypeScriptVoid)
          }).toMap)
        })
    }

    tssInterface.quit()

    mappedStructures.toMap
  }

}