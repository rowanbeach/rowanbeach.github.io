package com.rowanbeach.spabindingvalidator.bindingmarkup.spaframeworks.durandal

import com.rowanbeach.spabindingvalidator.bindingmarkup._
import com.typesafe.scalalogging.LazyLogging

import scala.collection.JavaConversions._
import scala.util.parsing.combinator

/**
 * Describes a single binding type
 * @param bindingName this is the main binding type name such as "visible" or "attr"
 */
case class DurandalBindingType(bindingName: String)

//, subType: Option[String])

object DurandalParser {

  private object DurandalParsers extends combinator.JavaTokenParsers {

    val withParensBindingRegex = """[a-zA-Z0-9]+(\(\))?""".r

    val withDotsAndParensBindingRegex = """[a-zA-Z0-9\.]+(\(\))?""".r

    val noParensBindingRegex = """[a-zA-Z0-9]+""".r

    val jsKey = "[a-zA-Z0-9]+".r

    lazy val simpleAttributeBinding = repsep(withParensBindingRegex, '.') ^^ { case x => x.map(y => HTMLSimpleBindingContextName(y)) }

    //      val jsKeyValue = (jsKey <~ ":") ~ withDotsAndParensBindingRegex ^^ { case (key ~ value) => DurandalBinding(DurandalBindingType(key), value) }
    val jsKeyValue = (jsKey <~ ":") ~ simpleAttributeBinding ^^ { case (key ~ value) => HTMLBinding(value, key, HTMLBindingString) }

    val jsKeyValueList = repsep(jsKeyValue, ",")

    val objectBody = "{" ~> jsKeyValueList <~ "}"

    /**
     * This represents an object binding with zero to many keys in the objectBody. The object is flattened with the outer name of the binding
     * forming the bindingName of the DurandalBindingType, potentially repeating therefore, and the inner name forming the binding expression
     */
    val objectBinding = (jsKey <~ ":") ~ objectBody ^^ { case (key ~ values) => values.map(x => x.copy(bindingName = key)) }

    val mainParser = objectBinding | jsKeyValueList

    lazy val withContextBinding = "with" ~ ":" ~ simpleAttributeBinding ^^ {
      case _ ~ bindingNames => bindingNames.reverse match {
        case Nil => Nil
        case head :: tail => (HTMLSimpleBindingContextName(head.bindingName) :: tail).reverse
      }
    }

    lazy val forEachContextBinding = "foreach" ~ ":" ~ simpleAttributeBinding ^^ {
      case _ ~ bindingNames => bindingNames.reverse match {
        case Nil => Nil
        case head :: tail => (HTMLArrayBindingContextName(head.bindingName, "") :: tail).reverse
      }
    }

    lazy val childContextBinding = forEachContextBinding | withContextBinding

    lazy val functionTypeBinding: DurandalParsers.Parser[(String, Option[HTMLBindingType])] = noParensBindingRegex <~ "()" ^^ { case valueWithNoParens => (valueWithNoParens, Some(HTMLBindingFunction(HTMLBindingVoid))) }

  }

  def parse(text: String): List[HTMLBinding] = DurandalParsers.parseAll(DurandalParsers.mainParser, text).getOrElse(Nil)

  def parseChildContextBindingName(attributeValue: String): List[HTMLBindingContextName] = DurandalParsers.parseAll(DurandalParsers.childContextBinding, attributeValue).getOrElse(Nil)

  def parseBindingNameAndTypeFromBindingExpression(bindingExpression: String): (String, Option[HTMLBindingType]) = DurandalParsers.parseAll(DurandalParsers.functionTypeBinding, bindingExpression).getOrElse(bindingExpression, None)

}

object DurandalParsingStrategy extends SpaParsingStrategy with LazyLogging {

  val bindingTypes = Map("visible" -> HTMLBindingBoolean).withDefaultValue(HTMLBindingString)

  def parseChildContextBindingValue(bindingContext: List[HTMLBindingContextName], bindingValue: String): List[HTMLBindingContextName] = {

    bindingContext ::: DurandalParser.parseChildContextBindingName(bindingValue)

  }

  //  def childScopeName(markupNode: MarkupNode): String = {
  //    val withBindingText = markupNode.node.attr("with")
  //    val x = DurandalExpressionParser.parse(withBindingText)
  //    if (x.isEmpty) "" else x.head.bindingExpression
  //  }

  def getAttributeBindings(bindingContext: List[HTMLBindingContextName], node: MarkupNode): List[HTMLBinding] = {
    node.node.attributes().filter(_.getKey == "data-bind").toList.flatMap(x => {
      DurandalParser.parse(x.getValue)
    })
  }

  def getChildContextBinding(bindingContext: List[HTMLBindingContextName], node: ElementMarkupNode) = {

    val x = node.node.attr("data-bind") match {
      case "" => bindingContext
      case v => parseChildContextBindingValue(bindingContext, v)
    }

    x
  }

  val ignoreBindings = List("with", "foreach")

  override def parseMarkupTree(rootNode: MarkupNode): List[HTMLBinding] = {

    def innerParseMarkupNode(node: MarkupNode, bindingContext: List[HTMLBindingContextName]): List[HTMLBinding] = node match {
      case textMarkupNode: TextMarkupNode => Nil // No handlebars style bindings in supported KnockoutJS versions
      case elementMarkupNode: ElementMarkupNode =>

        val childBindContext = getChildContextBinding(bindingContext, elementMarkupNode)

        val localAttributeBindings = getAttributeBindings(bindingContext, elementMarkupNode)

        // Don't include structural 'name-spacing' elements as bindings as they are not leaf bindings, they just give context to
        // elements further down in the binding hierarchy
        val leafBindings = localAttributeBindings.filterNot(ab => ignoreBindings.contains(ab.bindingName))

        val localHTMLBindings = leafBindings.map(x => {
          val bindingContextNames = x.bindingContext.reverse
          val (bindingName, bindingType) = DurandalParser.parseBindingNameAndTypeFromBindingExpression(bindingContextNames.head.bindingName)
          val resolvedBindingType = bindingType.getOrElse(bindingTypes(x.bindingName))
          HTMLBinding(bindingContext ::: bindingContextNames.tail.reverse, bindingName, resolvedBindingType)
        })

        localHTMLBindings union elementMarkupNode.children.flatMap(x => innerParseMarkupNode(x, childBindContext))
      case commentMarkupNode: CommentMarkupNode => Nil // No support for comment bindings yet
    }

    innerParseMarkupNode(rootNode, Nil)
  }

}
