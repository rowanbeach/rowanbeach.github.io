package com.rowanbeach.spabindingvalidator

import java.io.{File, FilenameFilter}

package object common {

  implicit class ImplicitFilenameFilter(p: (File, String) => Boolean) extends FilenameFilter {
    override def accept(dir: File, name: String): Boolean = p(dir, name)
  }

}
