package com.rowanbeach.spabindingvalidator.common

object ViewModelNameResolutionStrategies {

  /**
   * interfaceNameMatchingStrategy is a curried function (String => String => String)
   * Calling the initial function with a viewModelPrefix results in a function (String => String) which is the viewmodel name resolver
   *
   * interfaceNameMatchingStrategy is the sole supported view model name resolution strategy
   * others could be added simply by implementing a function (String => String)
   */
  def interfaceNameMatchingStrategy(viewModelPrefix: String)(path: String): String = {
    val fileName = path.substring((path.lastIndexOf('/') + 1).max(0))
    val viewModelName = s"I${fileName(0).toUpper}${fileName.substring(1).replace(".html", "")}ViewModel"
    List(viewModelPrefix, viewModelName).mkString(".")
  }

}
