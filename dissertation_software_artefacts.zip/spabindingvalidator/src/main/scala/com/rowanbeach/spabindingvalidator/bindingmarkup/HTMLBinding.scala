package com.rowanbeach.spabindingvalidator.bindingmarkup

trait HTMLBindingContextName {
  val bindingName: String
}

case class HTMLSimpleBindingContextName(bindingName: String) extends HTMLBindingContextName

case class HTMLArrayBindingContextName(bindingName: String, arrayElementPrefix: String) extends HTMLBindingContextName

case class HTMLBinding(bindingContext: List[HTMLBindingContextName], bindingName: String, bindingType: HTMLBindingType)

trait HTMLBindingType

trait HTMLBindingPrimitiveType extends HTMLBindingType

object HTMLBindingPrimitiveType {
  def apply(typeName: String): HTMLBindingPrimitiveType = typeName match {
    case "void" => HTMLBindingVoid
    case "string" => HTMLBindingString
    case "number" => HTMLBindingNumber
    case "boolean" | "Boolean" => HTMLBindingBoolean
    case "Date" => HTMLBindingDate
    case "any" => HTMLBindingAny
  }
}

case object HTMLBindingBoolean extends HTMLBindingPrimitiveType {
  override val toString = "boolean"
}

case object HTMLBindingDate extends HTMLBindingPrimitiveType {
  override val toString = "Date"
}

case object HTMLBindingAny extends HTMLBindingPrimitiveType {
  override val toString = "any"
}

case class HTMLBindingAnyWithName(name: String) extends HTMLBindingPrimitiveType {
  override val toString = s"any: $name"
}

case object HTMLBindingNumber extends HTMLBindingPrimitiveType {
  override val toString = "number"
}

case object HTMLBindingString extends HTMLBindingPrimitiveType {
  override val toString = "string"
}

case object HTMLBindingVoid extends HTMLBindingPrimitiveType {
  override val toString = "void"
}

case class HTMLBindingFunction(returnType: HTMLBindingType) extends HTMLBindingType {
  override val toString = s"() => $returnType"
}

case object HTMLBindingArray extends HTMLBindingType {
  override val toString = s"array"
}
