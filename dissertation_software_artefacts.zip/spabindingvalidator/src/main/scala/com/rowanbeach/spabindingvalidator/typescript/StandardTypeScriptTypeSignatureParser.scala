package com.rowanbeach.spabindingvalidator.typescript

import com.typesafe.scalalogging.LazyLogging

import scala.util.parsing.combinator._

trait TypeScriptTypeSignatureParser {

  def parse(typeName: String, containerNamespace: String): TypeScriptType

  def parseTypeParameterNamesForComplexType(typeName: String): List[TypeScriptTypeParameterPlaceholder]

}

object StandardTypeScriptTypeSignatureParser extends TypeScriptTypeSignatureParser with LazyLogging {

  private object TypeScriptParsers extends JavaTokenParsers {
    val namespaceRegex = """^([A-Za-z0-9_]+\.)*""".r

    lazy val voidType: Parser[TypeScriptType] = "void" ^^ (x => TypeScriptVoid)
    lazy val primitiveType: Parser[TypeScriptPrimitiveType with ConvertibleToArray] = ("string" | "number" | "boolean" | "Boolean" | "Date" | "any") ^^ (x => TypeScriptPrimitiveType(x))
    lazy val nonParameterisedType: Parser[TypeScriptSimpleTypeRef] = (namespaceRegex ~ ident) ^^ {
      case namespace ~ typeName => TypeScriptSimpleTypeRef(typeName, "", if (namespace.endsWith(".")) namespace.substring(0, namespace.length - 1) else namespace, Nil)
    }

    lazy val singleType: Parser[TypeScriptType] = voidType | primitiveType | nonParameterisedType

    lazy val array: Parser[TypeScriptType] = (parameterisedType | primitiveType | nonParameterisedType) <~ "[]" ^^ (x => x.asArray)
    lazy val parameterisedType: Parser[TypeScriptSimpleTypeRef] = (namespaceRegex ~ ident) ~ "<" ~ repsep(array | parameterisedType | singleType, ",") ~ ">" ^^ {
      case namespace ~ typeName ~ "<" ~ typeParameters ~ ">" => TypeScriptSimpleTypeRef(typeName, "", if (namespace.endsWith(".")) namespace.substring(0, namespace.length - 1) else namespace, typeParameters)
    }
    lazy val typeDefinition: Parser[TypeScriptType] = lambdaFunction | array | parameterisedType | voidType | primitiveType | nonParameterisedType

    /**
     * This is a limited function definition parser
     * It will parse simple no-parameter functions which are declared using lambda syntax such as
     * () => void
     * or
     * () => string
     * This should be sufficient for many view models but this area of the TypeScript parser may need expansion in the future
     */
    lazy val lambdaFunction: Parser[TypeScriptFunction] = "()" ~> "=>" ~> typeDefinition ^^ {
      case x => TypeScriptFunction(x)
    }

    lazy val containerDefinition: Parser[List[String]] = ident ~ "<" ~ repsep(ident, ",") ~ ">" ^^ {
      case typeName ~ "<" ~ typeParameters ~ ">" => typeParameters
    }
  }

  def withDeclaringContainerNamespace(typeScriptType: TypeScriptType, declaringContainerNamespace: String): TypeScriptType = typeScriptType match {
    case r: TypeScriptTypeRef => r.withDeclaringContainerNamespace(declaringContainerNamespace).withTypeParameters(r.typeParameters.map(tp => withDeclaringContainerNamespace(tp, declaringContainerNamespace)))
    case anythingElse => anythingElse
  }

  def parse(typeName: String, containerNamespace: String): TypeScriptType = {
    withDeclaringContainerNamespace(TypeScriptParsers.parseAll(TypeScriptParsers.typeDefinition, typeName).getOrElse(TypeScriptParseFailure(typeName)), containerNamespace)
  }

  def parseTypeParameterNamesForComplexType(typeName: String): List[TypeScriptTypeParameterPlaceholder] = {
    logger.info(s"parseTypeParametersForComplexType: $typeName")
    val x = TypeScriptParsers.parseAll(TypeScriptParsers.containerDefinition, typeName).getOrElse(Nil).map(TypeScriptTypeParameterPlaceholder)
    x
  }

}
