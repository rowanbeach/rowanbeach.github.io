package com.rowanbeach.spabindingvalidator.common

object SupportedSpaType extends Enumeration {
  type SupportedSpaType = Value
  val AngularJS, Durandal = Value
}
