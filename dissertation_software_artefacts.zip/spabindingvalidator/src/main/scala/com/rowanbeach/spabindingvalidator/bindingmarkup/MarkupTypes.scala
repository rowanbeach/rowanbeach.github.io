package com.rowanbeach.spabindingvalidator.bindingmarkup

import org.jsoup.nodes.{Comment, Element, TextNode, Node}

trait MarkupNode {
  def tagName: String

  def node: Node

  def children: List[MarkupNode]
}

case class TextMarkupNode(node: TextNode, children: List[MarkupNode]) extends MarkupNode {
  val tagName = "text"

  override val toString = s"text ${node.text()}"
}

case class ElementMarkupNode(node: Element, children: List[MarkupNode]) extends MarkupNode {
  val tagName = node.tagName()

  override val toString = s"element - $tagName - $children"
}

case class CommentMarkupNode(node: Comment, children: List[MarkupNode]) extends MarkupNode {
  val tagName = "comment"

  override val toString = s"comment ${node.toString}"
}

