package com.rowanbeach.spabindingvalidator.bindingmarkup

import com.rowanbeach.spabindingvalidator.common._

object HTMLBindingsToCommonASTTransformer {

  def transform(htmlBindings: List[HTMLBinding]): CommonASTMemberContainer = {

    val maxNamespaceLength = if (htmlBindings.isEmpty) 0 else htmlBindings.map(x => x.bindingContext.length).max

    val levels = for (i <- 0 to maxNamespaceLength) yield {
      htmlBindings.map(x => x.bindingContext.take(i)).filter(x => x.length == i).distinct
    }

    def getBindingsForContainerParts(namespace: List[HTMLBindingContextName]): Map[String, CommonASTType] = {
      val levelIndex = namespace.length

      val leafBindings: List[(String, CommonASTType)] = htmlBindings.collect({
        case x if x.bindingContext == namespace => (x.bindingName, x.bindingType match {
          // TODO - extend this list
          case HTMLBindingBoolean => CommonASTBoolean
          case HTMLBindingFunction(returnType) => CommonASTFunction(CommonASTVoid) // Always map to a void return type for now
          case _ => CommonASTString
        })
      })

      if (levelIndex < levels.length - 1) {
        val childContainerNamespaces: List[(String, CommonASTType)] = levels(levelIndex + 1)
          .filter(x => x.startsWith(namespace))
          .map(x => x(levelIndex) match {
          case ab: HTMLArrayBindingContextName => ab.bindingName -> CommonASTTypeContainerArray(getBindingsForContainerParts(x))
          case sb: HTMLSimpleBindingContextName => sb.bindingName -> CommonASTTypeContainer(getBindingsForContainerParts(x))
        })

        childContainerNamespaces.union(leafBindings).toMap
      } else {
        leafBindings.toMap
      }

    }

    CommonASTTypeContainer(getBindingsForContainerParts(Nil))

  }

}
