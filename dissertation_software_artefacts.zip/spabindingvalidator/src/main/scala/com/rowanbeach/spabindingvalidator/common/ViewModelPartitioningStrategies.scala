package com.rowanbeach.spabindingvalidator.common

case class ViewModelPartitioningResult(bindingRoot: Option[CommonASTMemberContainer], membersOutsideBindingRoot: List[(String, CommonASTType)])

object ViewModelPartitioningStrategies {

  /**
   * This partitions the viewmodel starting at the container passed in, applying the accessor
   * @param viewModelBindingRootAccessor this is the dotted name which represents the accessor for the root of the viewmodel binding
   * @param commonASTTypeContainer this represents the root of the binding context for the current matching operation. The viewModelBindingRootAccessor
   *                               will normally be a member of this container
   * @return a ViewModelPartitioningResult containing the binding root and a list of members which were found outside the binding root
   */
  def accessorPartitioner(viewModelBindingRootAccessor: String)(commonASTTypeContainer: CommonASTMemberContainer): ViewModelPartitioningResult = {

    def innerMatcher(namespaceElements: List[String], typeContainer: CommonASTMemberContainer): Option[CommonASTMemberContainer] = {

      namespaceElements.foldLeft(Some(commonASTTypeContainer): Option[CommonASTMemberContainer]) { (acc, key) =>
        acc match {
          case None => None
          case Some(container) => container.getChildContainer(key)
        }
      }
    }

    val allNamespaceElements = viewModelBindingRootAccessor.split('.').toList

    ViewModelPartitioningResult(innerMatcher(allNamespaceElements, commonASTTypeContainer), commonASTTypeContainer.members.filter(x => {
      x._1 != allNamespaceElements.head
    }).toList)

  }

  /**
   * This is a partitioning strategy which just returns the passed in container as the result of the partitioning action. Use this when no partitioning is required
   * @param commonASTTypeContainer this will be the result of the partition
   * @return A tuple containing the passed in type container and an empty list
   */
  def identityPartitioner(commonASTTypeContainer: CommonASTMemberContainer): ViewModelPartitioningResult = ViewModelPartitioningResult(Some(commonASTTypeContainer), Nil)

}
