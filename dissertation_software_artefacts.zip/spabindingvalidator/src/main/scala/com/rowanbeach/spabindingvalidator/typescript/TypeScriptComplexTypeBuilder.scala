package com.rowanbeach.spabindingvalidator.typescript

import com.typesafe.scalalogging.LazyLogging
import com.rowanbeach.spabindingvalidator.common.Utils._

object TypeScriptComplexTypeBuilder extends LazyLogging {

  // 4 - resolve type references and construct parameterised types from generic types
  def buildFrom(flatComplexTypeMap: Map[String, TypeScriptComplexType]): Map[String, TypeScriptComplexType] = {

    def constructTypeFromGenericType(genericType: TypeScriptGenericType, typeParameters: List[TypeScriptType], containerNamespaceContext: String): TypeScriptType = {
      val parameterMap = genericType.typeParameterPlaceholders.zip(typeParameters).map({ case (pl, pa) => (pl.slotName, pa) }).toMap

      val constructedResult = TypeScriptNonGenericType(genericType.members.map {
        case (memberName, memberType) =>
          memberType match {
            case t: TypeScriptArrayTypeParameterRef => parameterMap.get(t.typeParameterName) match {
              case Some(typeScriptType) => typeScriptType match {
                case r: TypeScriptTypeRef => memberName -> (resolveTypeRef(r, r.declaringContainerNamespace) match {
                  case a: ConvertibleToArray => a.asArray
                  case other => other
                })
                case anythingElse => memberName -> (resolveType(anythingElse) match {
                  case a: ConvertibleToArray => a.asArray
                  case other => other
                })
              }
              case _ => memberName -> TypeScriptUnresolvedTypeParameter(t.toString)
            }
            case t: TypeScriptTypeParameterRef => parameterMap.get(t.typeParameterName) match {
              case Some(typeScriptType) => typeScriptType match {
                case r: TypeScriptTypeRef => memberName -> resolveTypeRef(r, r.declaringContainerNamespace)
                case anythingElse => memberName -> resolveType(anythingElse)
              }
              case _ => memberName -> TypeScriptUnresolvedTypeParameter(t.toString)
            }
            case r: TypeScriptTypeRef =>
              val resolvedTypeParameters = parameterMap.map({ case (key, value) => key -> resolveType(value) })
              val typeParametersToUse = r.typeParameters.map({
                // Look up type parameters in the parameter map by name
                case parameterRef: TypeScriptArrayTypeParameterRef => resolvedTypeParameters.getOrElse(parameterRef.typeParameterName, TypeScriptUnresolvedTypeParameter(parameterRef.typeParameterName)) match {
                  case a: ConvertibleToArray => a.asArray
                  case other => other
                }
                case parameterRef: TypeScriptSimpleTypeParameterRef => resolvedTypeParameters.getOrElse(parameterRef.typeParameterName, TypeScriptUnresolvedTypeParameter(parameterRef.typeParameterName))
                case anythingElse => anythingElse
              })
              memberName -> resolveTypeRef(r.withTypeParameters(typeParametersToUse), r.declaringContainerNamespace)
            case _ => memberName -> resolveType(memberType)
          }
      })

      constructedResult
    }

    def resolveTypeRef(ref: TypeScriptTypeRef, containerNamespaceContext: String): TypeScriptType = {

      logger.debug(s"resolveTypeRef called for $ref with containerNamespaceContext $containerNamespaceContext")

      val fqn = concatenateNamespaceElements(containerNamespaceContext, ref.relativeNamespace, ref.typeName)

      lazyComplexTypeDefinitions.get(fqn) match {
        case None => containerNamespaceContext match {
          case "" =>
            logger.warn(s"Unable to find $fqn - returning TypeScriptUnresolvedTypeReference ${ref.typeName}")
            TypeScriptUnresolvedTypeReference(ref.typeName)
          case someNamespace => resolveTypeRef(ref, stripLastElementOfDottedName(containerNamespaceContext)) // call recursively and take the end off the container namespace
        }
        case Some(typeResult) =>
          logger.info(s"Found $typeResult for $fqn")
          typeResult() match {
            case gt: TypeScriptGenericType =>
              val containerNamespaceForLookups = concatenateNamespaceElements(containerNamespaceContext, ref.relativeNamespace)
              constructTypeFromGenericType(gt, ref.typeParameters, containerNamespaceForLookups)
            case ct: TypeScriptComplexType => ref match {
              case ar: TypeScriptArrayTypeRef => TypeScriptNonGenericTypeArray(ct.members)
              case anythingElse => ct
            }
            case anythingElse => anythingElse
          }
      }

    }

    def resolveType(typeScriptType: TypeScriptType): TypeScriptType = typeScriptType match {
      case r: TypeScriptTypeRef => resolveTypeRef(r, r.declaringContainerNamespace)
      case anythingElse => anythingElse
    }

    lazy val lazyComplexTypeDefinitions = flatComplexTypeMap.map({
      case (complexTypeFullyQualifiedName, complexType) => complexTypeFullyQualifiedName -> (complexType match {
        case g: TypeScriptGenericType => () => g
        case ng: TypeScriptNonGenericType => () => {
          logger.debug(s"evaluating lazyComplexTypeDefinition for NonGenericType $complexTypeFullyQualifiedName")
          TypeScriptNonGenericType(complexType.members.map({
            case (memberName, memberType) =>
              memberName -> resolveType(memberType)
          }))
        }
      })
    })

    val evaluatedDefinitions = lazyComplexTypeDefinitions.map({ case (name, typeScriptComplexType) => name -> typeScriptComplexType() })

    val nonGenericComplexTypeDefinitionMap = evaluatedDefinitions.collect({ case (name, typeScriptNonGenericType: TypeScriptNonGenericType) => name -> typeScriptNonGenericType })

    nonGenericComplexTypeDefinitionMap

  }

}
