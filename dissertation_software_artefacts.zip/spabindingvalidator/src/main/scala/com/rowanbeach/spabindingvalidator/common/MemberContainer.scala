package com.rowanbeach.spabindingvalidator.common

trait MemberContainer {
  val members: Map[String, Any]
}
