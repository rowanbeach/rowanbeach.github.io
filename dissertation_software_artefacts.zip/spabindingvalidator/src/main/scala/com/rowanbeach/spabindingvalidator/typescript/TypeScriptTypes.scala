package com.rowanbeach.spabindingvalidator.typescript

import com.rowanbeach.spabindingvalidator.common.{Utils, MemberContainer}
import com.typesafe.scalalogging.LazyLogging

trait TypeScriptType

trait ConvertibleToArray {
  val asArray: TypeScriptType
}

trait TypeScriptPrimitiveType extends TypeScriptType

object TypeScriptPrimitiveType {
  def apply(typeName: String): TypeScriptPrimitiveType with ConvertibleToArray = typeName match {
    case "string" => TypeScriptString
    case "number" => TypeScriptNumber
    case "boolean" | "Boolean" => TypeScriptBoolean
    case "Date" => TypeScriptDate
    case "any" => TypeScriptAny
  }
}

case object TypeScriptBoolean extends TypeScriptPrimitiveType with ConvertibleToArray {
  override val toString = "boolean"
  val asArray = TypeScriptBooleanArray
}

case object TypeScriptDate extends TypeScriptPrimitiveType  with ConvertibleToArray{
  override val toString = "Date"
  val asArray = TypeScriptDateArray
}

case object TypeScriptAny extends TypeScriptPrimitiveType  with ConvertibleToArray{
  override val toString = "any"
  val asArray = TypeScriptAnyArray
}

case object TypeScriptNumber extends TypeScriptPrimitiveType  with ConvertibleToArray{
  override val toString = "number"
  val asArray = TypeScriptNumberArray
}

case object TypeScriptString extends TypeScriptPrimitiveType  with ConvertibleToArray{
  override val toString = "string"
  val asArray = TypeScriptStringArray
}

case object TypeScriptVoid extends TypeScriptType {
  override val toString = "void"
  val asArray: TypeScriptType = TypeScriptVoid
}

case object TypeScriptBooleanArray extends TypeScriptPrimitiveType with TypeScriptArray {
  override val toString = "boolean[]"
}

case object TypeScriptDateArray extends TypeScriptPrimitiveType with TypeScriptArray {
  override val toString = "Date[]"
}

case object TypeScriptAnyArray extends TypeScriptPrimitiveType with TypeScriptArray {
  override val toString = "any[]"
}

case object TypeScriptNumberArray extends TypeScriptPrimitiveType with TypeScriptArray {
  override val toString = "number[]"
}

case object TypeScriptStringArray extends TypeScriptPrimitiveType with TypeScriptArray {
  override val toString = "string[]"
}

case class TypeScriptFunction(returnType: TypeScriptType) extends TypeScriptType {
  override val toString = s"() => $returnType"
}

trait TypeScriptArray

trait TypeScriptTypeRef extends TypeScriptType {
  val typeName: String
  val declaringContainerNamespace: String
  val relativeNamespace: String
  val typeParameters: List[TypeScriptType]
  val absoluteNamespaceParts = if (relativeNamespace.isEmpty) Nil else relativeNamespace.split('.').toList

  def withTypeParameters(typeParameters: List[TypeScriptType]): TypeScriptTypeRef

  def withDeclaringContainerNamespace(namespace: String): TypeScriptTypeRef

  val fullTypeNameDisplay = s"${if (declaringContainerNamespace.isEmpty) "" else s"{$declaringContainerNamespace.}"}${Utils.concatenateNamespaceElements(relativeNamespace, typeName)}"
  lazy val genericParameterString = if (typeParameters == Nil) "" else "<" + typeParameters.mkString(",") + ">"
}

case class TypeScriptSimpleTypeRef(typeName: String, declaringContainerNamespace: String, relativeNamespace: String, typeParameters: List[TypeScriptType]) extends TypeScriptTypeRef with LazyLogging with ConvertibleToArray {

  override val toString = s"type_ref: $fullTypeNameDisplay$genericParameterString"

  def withTypeParameters(typeParameters: List[TypeScriptType]) = this.copy(typeParameters = typeParameters)

  override def withDeclaringContainerNamespace(declaringContainerNamespace: String): TypeScriptTypeRef = this.copy(declaringContainerNamespace = declaringContainerNamespace)

  lazy val asArray: TypeScriptType = TypeScriptArrayTypeRef(typeName, declaringContainerNamespace, relativeNamespace, typeParameters)
}

case class TypeScriptArrayTypeRef(typeName: String, declaringContainerNamespace: String, relativeNamespace: String, typeParameters: List[TypeScriptType]) extends TypeScriptTypeRef with TypeScriptArray with LazyLogging {

  override val toString = s"type_ref[]: $fullTypeNameDisplay$genericParameterString"

  def withTypeParameters(typeParameters: List[TypeScriptType]) = this.copy(typeParameters = typeParameters)

  override def withDeclaringContainerNamespace(declaringContainerNamespace: String): TypeScriptTypeRef = this.copy(declaringContainerNamespace = declaringContainerNamespace)

}

trait TypeScriptTypeParameterRef {
  val typeParameterName: String
}

case class TypeScriptSimpleTypeParameterRef(typeParameterName: String) extends TypeScriptType with TypeScriptTypeParameterRef with ConvertibleToArray {
  override val toString = {
    s"type_parameter_ref: $typeParameterName"
  }

  lazy val asArray: TypeScriptType = TypeScriptArrayTypeParameterRef(typeParameterName)
}

case class TypeScriptArrayTypeParameterRef(typeParameterName: String) extends TypeScriptType with TypeScriptTypeParameterRef {
  override val toString = {
    s"type_parameter_ref[]: $typeParameterName"
  }

}

case class TypeScriptParseFailure(textValue: String) extends TypeScriptType {
  override val toString = s"ParseFailure($textValue)"
}

case class TypeScriptUnresolvedTypeReference(typeName: String) extends TypeScriptType {
  override val toString = s"TypeScriptUnresolvedTypeReference($typeName)"
}

case class TypeScriptUnresolvedTypeParameter(name: String) extends TypeScriptType {
  override val toString = s"TypeScriptUnresolvedTypeParameter($name)"
}

case class TypeScriptTypeParameterPlaceholder(slotName: String) extends TypeScriptType {
  override def toString = slotName
}

/**
 * A trait (similar to an interface in object oriented languages but with optional implementations) to describe a container
 */
trait TypeScriptMemberContainer extends TypeScriptType with MemberContainer {
  val members: Map[String, TypeScriptType]

  /**
   * Try to get a member by name
   * @param name The member name
   * @return Some[TypeScriptType] or None
   */
  def apply(name: String): Option[TypeScriptType] = members.get(name)

  /**
   * Helper function to get a complex type by name
   * @param name The member name
   * @return Some[TypeScriptComplexType] or None
   */
  def getComplexType(name: String): Option[TypeScriptComplexType] = {
    apply(name) match {
      case Some(x) => x match {
        case y: TypeScriptComplexType => Some(y)
        case _ => None
      }
      case _ => None
    }
  }

  /**
   * Helper function to get a typescript type container (module) by name
   * @param name The member name
   * @return Some[TypeScriptModule] or None
   */
  def getContainerOption(name: String): Option[TypeScriptModule] = members.get(name).collect({ case b: TypeScriptModule => b })
}

case class TypeScriptModule(members: Map[String, TypeScriptType]) extends TypeScriptMemberContainer {

  override val toString = "TypeScriptModule"

}

trait TypeScriptComplexType extends TypeScriptMemberContainer {

  override val toString = "TypeScriptComplexType"

}

case class TypeScriptNonGenericType(members: Map[String, TypeScriptType]) extends TypeScriptComplexType with ConvertibleToArray {

  override val toString = "TypeScriptNonGenericType"
  val asArray = TypeScriptNonGenericTypeArray(members)

}

case class TypeScriptNonGenericTypeArray(members: Map[String, TypeScriptType]) extends TypeScriptComplexType with TypeScriptArray {

  override val toString = "TypeScriptNonGenericTypeArray"

}

case class TypeScriptGenericType(typeParameterPlaceholders: List[TypeScriptTypeParameterPlaceholder], members: Map[String, TypeScriptType]) extends TypeScriptComplexType with MemberContainer {

  def hasParameterPlaceholder(parameterPlaceholder: TypeScriptTypeParameterPlaceholder) = typeParameterPlaceholders.contains(parameterPlaceholder)

  override val toString = {
    val typeParameterPlaceholderDisplay = if (typeParameterPlaceholders.isEmpty) " " else s" <${typeParameterPlaceholders.mkString(",")}>"
    s"TypeScriptGenericType $typeParameterPlaceholderDisplay".trim
  }

}
