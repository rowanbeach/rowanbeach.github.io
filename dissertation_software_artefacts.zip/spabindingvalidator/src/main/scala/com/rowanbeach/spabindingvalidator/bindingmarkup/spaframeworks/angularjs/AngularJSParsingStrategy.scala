package com.rowanbeach.spabindingvalidator.bindingmarkup.spaframeworks.angularjs

import com.rowanbeach.spabindingvalidator.bindingmarkup._
import com.typesafe.scalalogging.LazyLogging

import scala.collection.JavaConversions._
import scala.util.parsing.combinator

object AngularParser {


  private object AngularParsers extends combinator.JavaTokenParsers {

    val withParensBindingRegex = """[a-zA-Z0-9]+(\(\))?""".r

    val noParensBindingRegex = """[a-zA-Z0-9]+""".r

    /**
     * This regex uses a negated character class rather than a lazy quantifier on the * to maximise
     * performance and the group is declared as non-capturing as the value here is discarded
     */
    lazy val startBracesWithOptionalExtraCharsAtTheStart = """(?:.[^\{])*\{\{""".r

    lazy val attributeLiteralBindingContent = """[^']*""".r

    lazy val attributeNonLiteralBinding = """[0-9A-Za-z_\.]+""".r

    lazy val angularTextBindingWithExtraCharsAtTheStart = startBracesWithOptionalExtraCharsAtTheStart ~> repsep(withParensBindingRegex, '.') <~ "}}"

    lazy val angularBindingTextSection = rep(angularTextBindingWithExtraCharsAtTheStart) ^^ { case bindingStrings => bindingStrings.map(x => x.map(y => HTMLSimpleBindingContextName(y))) }

    lazy val attributeLiteral = "'" ~> attributeLiteralBindingContent <~ "'" ^^ { case _ => Nil }

    lazy val simpleAttributeBinding = repsep(withParensBindingRegex, '.') ^^ { case x => x.map(y => HTMLSimpleBindingContextName(y)) }

    lazy val inlineAttributeBinding = startBracesWithOptionalExtraCharsAtTheStart ~> repsep(withParensBindingRegex, '.') <~ "}}" ^^ { case x => x.map(y => HTMLSimpleBindingContextName(y)) }

    lazy val attribute: AngularParsers.Parser[List[HTMLBindingContextName]] = attributeLiteral | inlineAttributeBinding | simpleAttributeBinding

    lazy val functionTypeBinding: AngularParsers.Parser[HTMLBindingType] = noParensBindingRegex <~ "()" ^^ { case _ => HTMLBindingFunction(HTMLBindingVoid) }

    lazy val removeFunctionParens: AngularParsers.Parser[String] = noParensBindingRegex <~ "()"

    lazy val arrayContextBinding = attributeNonLiteralBinding ~ "in" ~ simpleAttributeBinding ^^ {
      case arrayElementPrefix ~ _ ~ bindingNames => bindingNames.reverse match {
        case Nil => Nil
        case head :: tail => (HTMLArrayBindingContextName(head.bindingName, arrayElementPrefix) :: tail).reverse
      }
    }

    lazy val childContextBinding = arrayContextBinding | simpleAttributeBinding

  }

  def parseBindingContextNameForTextValue(textValue: String): List[List[HTMLBindingContextName]] = AngularParsers.parseAll(AngularParsers.angularBindingTextSection, textValue).getOrElse(Nil)

  def parseBindingContextNameForAttributeValue(attributeValue: String): List[HTMLBindingContextName] = AngularParsers.parseAll(AngularParsers.attribute, attributeValue).getOrElse(Nil)

  def parseChildContextBindingName(attributeValue: String): List[HTMLBindingContextName] = AngularParsers.parseAll(AngularParsers.childContextBinding, attributeValue).getOrElse(Nil)

  def parseBindingTypeFromNamePart(bindingName: String): HTMLBindingType = AngularParsers.parseAll(AngularParsers.functionTypeBinding, bindingName).getOrElse(HTMLBindingString)

  def removeFunctionInvocationParens(bindingName: String): String = AngularParsers.parseAll(AngularParsers.removeFunctionParens, bindingName).getOrElse(bindingName)

}

object AngularJSParsingStrategy extends SpaParsingStrategy with LazyLogging {

  val bindingTypes = Map("ng-show" -> HTMLBindingBoolean)

  def parseAttributeBindingValue(bindingContext: List[HTMLBindingContextName], attributeName: String, attributeValue: String): Option[HTMLBinding] = {

    AngularParser.parseBindingContextNameForAttributeValue(attributeValue).reverse match {
      case Nil => None
      case head :: tail => Some(HTMLBinding(bindingContext ::: tail.reverse, AngularParser.removeFunctionInvocationParens(head.bindingName), bindingTypes.getOrElse(attributeName, AngularParser.parseBindingTypeFromNamePart(head.bindingName))))
    }

  }

  def parseChildContextBindingValue(bindingContext: List[HTMLBindingContextName], bindingValue: String): List[HTMLBindingContextName] = {

    bindingContext ::: AngularParser.parseChildContextBindingName(bindingValue)

  }

  def getChildContextBinding(bindingContext: List[HTMLBindingContextName], node: ElementMarkupNode) = node.node.attr("ng-repeat") match {
    case v => parseChildContextBindingValue(bindingContext, v)
  }

  val ignoreBindings = List("ng-bind", "ng-repeat", "ng-controller")

  def getAttributeBindings(bindingContext: List[HTMLBindingContextName], node: MarkupNode): List[HTMLBinding] = {

    val x = node.node
      .attributes()
      .map(x => (x.getKey, x.getValue))
      .collect({ case (key, value) if key.startsWith("ng-") && !ignoreBindings.contains(key) => parseAttributeBindingValue(bindingContext, key, value) })
      .flatten.toList

    x

  }

  def getTextBindings(bindingContext: List[HTMLBindingContextName], text: String): List[HTMLBinding] = {

    val x = AngularParser.parseBindingContextNameForTextValue(text)

    val y: List[HTMLBinding] = x.map(x => x.reverse).collect({
      case head :: tail => HTMLBinding(bindingContext ::: tail.reverse, head.bindingName, HTMLBindingString)
    })

    y

  }

  def processArrayElementPrefixes(bindings: List[HTMLBindingContextName]): List[HTMLBindingContextName] = {
    bindings match {
      case Nil => Nil
      case head :: tail =>
        head match {
          case a: HTMLArrayBindingContextName =>
            val arrayElementPrefixCount = a.arrayElementPrefix.split('.').length

            tail match {
              case headOfTail :: tailOfTail if headOfTail.bindingName == a.arrayElementPrefix => head :: processArrayElementPrefixes(tail.drop(arrayElementPrefixCount)) // make sure the name of the binding reference matches
              case _ => bindings
            }

          case _ => head :: processArrayElementPrefixes(tail)
        }
    }
  }

  override def parseMarkupTree(rootNode: MarkupNode): List[HTMLBinding] = {

    def innerParseMarkupNode(node: MarkupNode, bindingContext: List[HTMLBindingContextName]): List[HTMLBinding] = node match {
      case textMarkupNode: TextMarkupNode => getTextBindings(bindingContext, textMarkupNode.node.text())
      case elementMarkupNode: ElementMarkupNode =>
        val childBindContext = getChildContextBinding(bindingContext, elementMarkupNode)
        getAttributeBindings(bindingContext, elementMarkupNode) union elementMarkupNode.children.flatMap(x => innerParseMarkupNode(x, childBindContext))
      case commentMarkupNode: CommentMarkupNode => Nil // Return an empty list in this case as there are no comment bindings in AngularJS
    }

    val htmlBindings = innerParseMarkupNode(rootNode, Nil)

    val y = htmlBindings.map(x => x.copy(bindingContext = processArrayElementPrefixes(x.bindingContext)))

    y

  }

}

