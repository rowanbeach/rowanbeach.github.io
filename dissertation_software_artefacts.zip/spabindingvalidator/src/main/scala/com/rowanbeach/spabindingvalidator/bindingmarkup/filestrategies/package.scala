package com.rowanbeach.spabindingvalidator.bindingmarkup

import java.io.File

import com.rowanbeach.spabindingvalidator.common.ImplicitFilenameFilter

package object filestrategies {

  def allViewFilenames(rootPath: String): List[String] = {

    val files = (for
      (file <- new File(rootPath).listFiles((a: File, b: String) => b.endsWith(".html")))
      yield file.getAbsolutePath).toList

    files

  }

  def singleViewFilename(path: String): List[String] = List(path)

}
