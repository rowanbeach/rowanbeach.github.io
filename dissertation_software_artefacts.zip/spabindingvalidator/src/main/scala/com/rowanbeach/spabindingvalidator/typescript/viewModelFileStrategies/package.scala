package com.rowanbeach.spabindingvalidator.typescript

import java.io.File

import com.rowanbeach.spabindingvalidator.common.ImplicitFilenameFilter
import com.typesafe.scalalogging.LazyLogging

package object viewModelFileStrategies extends LazyLogging {

  def allFilesInDirectory(rootPath: String): List[String] = {

    val files = (for
      (file <- new File(rootPath).listFiles((a: File, b: String) => b.endsWith("ViewModel.ts")))
      yield file.getCanonicalPath).toList

    files

  }

  def singleFile(path: String): List[String] = List(new File(path).getCanonicalPath)

}









