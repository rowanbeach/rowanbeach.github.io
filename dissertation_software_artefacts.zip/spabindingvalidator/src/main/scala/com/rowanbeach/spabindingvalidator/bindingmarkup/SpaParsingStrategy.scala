package com.rowanbeach.spabindingvalidator.bindingmarkup

trait SpaParsingStrategy {
  def parseMarkupTree(rootNode: MarkupNode) : List[HTMLBinding]
}
