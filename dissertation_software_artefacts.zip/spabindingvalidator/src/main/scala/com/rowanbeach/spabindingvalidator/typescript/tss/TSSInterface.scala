package com.rowanbeach.spabindingvalidator.typescript.tss

import java.io.{BufferedReader, InputStreamReader, PrintWriter}
import java.nio.charset.StandardCharsets
import java.nio.file.{Paths, Files}

import com.typesafe.scalalogging.LazyLogging

import scala.sys.process.{Process, ProcessIO}

class TSSInterface(rootPath: String, viewModelFilenames: List[String]) extends LazyLogging {

  val typeScriptSourceFilePath = rootPath + "spa_binding_validator_generated_references.ts"

  val fileContents = viewModelFilenames.map(x => s"/// <reference path='${x.replace(rootPath, "")}' />").mkString("\n")

  Files.write(Paths.get(typeScriptSourceFilePath), fileContents.getBytes(StandardCharsets.UTF_8))

  var input: TypeScriptToolsInput = null
  var output: TypeScriptToolsOutput = null

  val tssPath: String = "/usr/local/bin/tss"
  logger.debug(s"$tssPath $typeScriptSourceFilePath")

  val p = Process(tssPath, Seq(typeScriptSourceFilePath))
    .run(new ProcessIO(
    x => input = new TypeScriptToolsInput(new PrintWriter(x)),
    x => output = new TypeScriptToolsOutput(new BufferedReader(new InputStreamReader(x))),
    x => scala.io.Source.fromInputStream(x).getLines().foreach(println)))

  // TODO - determine whether it is feasible to take this sleep out and use a Future here or a similar construct which completes after the process has started
  Thread.sleep(100) // gives the tss process time to start

  // This should say something like: loaded /Users/steve/work/misc/dissertation/spabindingvalidator/viewmodels/dissertation_temp_all_vms.ts, TSS listening..
  private val firstLine = output.readStringLine()

  def fileStructure(filePath: String): List[TypeScriptMetadataStructure] = {
    logger.debug(s"structure $filePath")
    input.writeLine(s"structure $filePath")
    output.readStructureLine()
  }

  def definition(line: Int, character: Int, filePath: String): TypeScriptMetadataDefinition = {
    logger.debug(s"definition $line $character $filePath")
    input.writeLine(s"definition $line $character $filePath")
    output.readDefinitionLine()
  }

  def typeInfo(line: Int, character: Int, filePath: String): TypeScriptMetadataType = {
    logger.debug(s"type $line $character $filePath")
    input.writeLine(s"type $line $character $filePath")
    val x = output.readTypeLine()
    logger.info(s"typeInfoOutput: $x")
    x
  }

  def files: List[String] = {
    logger.debug(s"files")
    input.writeLine(s"files")
    val fileList = output.readFilesLine()
    val filteredFileList = fileList.filter(x => !(x.contains("typescript-tools/bin/lib.d.ts") || x.contains("typescript-tools/bin/defaultLibs.d.ts") || x.contains("spa_binding_validator_generated_references.ts")))
    logger.debug(filteredFileList.toString())
    filteredFileList
  }

  /** This makes the <code>TSSInterface</code> unusable so it should be the last thing which is called */
  def quit(): Unit = {
    Files.deleteIfExists(Paths.get(typeScriptSourceFilePath))
    input.writeLine("quit")
    //    logger.debug(output.readStringLine())
    p.destroy()
  }

}
