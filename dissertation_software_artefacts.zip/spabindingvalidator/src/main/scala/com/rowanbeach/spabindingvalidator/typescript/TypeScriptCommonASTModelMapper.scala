package com.rowanbeach.spabindingvalidator.typescript

import com.rowanbeach.spabindingvalidator.common._
import com.typesafe.scalalogging.LazyLogging

object TypeScriptCommonASTModelMapper extends LazyLogging {

  /**
   * mapAnyType returns an option monad which can be used with map, flatMap and for expressions to reduce complexity
   * while nonetheless supporting recursive filtering for unrecognised types. Unrecognised types are mapped to None
   * and will thus be filtered out with flatMap
   */
  private def mapAnyType(typeToMap: TypeScriptType): Option[CommonASTType] = typeToMap match {
    case module: TypeScriptModule => Some(CommonASTTypeContainer(mapMembers(module.members)))
    case nonGenericType: TypeScriptNonGenericType => Some(CommonASTTypeContainer(mapMembers(nonGenericType.members)))
    case nonGenericTypeArray: TypeScriptNonGenericTypeArray => Some(CommonASTTypeContainerArray(mapMembers(nonGenericTypeArray.members)))
    case TypeScriptFunction(a) => for {
      functionType <- mapAnyType(a)
    } yield CommonASTFunction(functionType)
    case TypeScriptVoid => Some(CommonASTVoid)
    case primitiveType: TypeScriptPrimitiveType => primitiveType match {
      case TypeScriptBoolean => Some(CommonASTBoolean)
      case TypeScriptDate => Some(CommonASTDate)
      case TypeScriptNumber => Some(CommonASTNumber)
      case TypeScriptString => Some(CommonASTString)
      case TypeScriptAny => Some(CommonASTAny)
      case TypeScriptBooleanArray => Some(CommonASTBooleanArray)
      case TypeScriptDateArray => Some(CommonASTDateArray)
      case TypeScriptNumberArray => Some(CommonASTNumberArray)
      case TypeScriptStringArray => Some(CommonASTStringArray)
      case TypeScriptAnyArray => Some(CommonASTAnyArray)
    }
    case unrecognisedType =>
      logger.warn(s"Ignoring unrecognised type: $unrecognisedType") // Anything unrecognised is not mapped
      None
  }

  def mapMembers(members: Map[String, TypeScriptType]): Map[String, CommonASTType] = {

    val x = for {
      (name, member) <- members
      commonASTType <- mapAnyType(member)
    } yield name -> commonASTType

    x

  }

  def mapComplexTypes(complexTypes: Map[String, TypeScriptComplexType]): Map[String, CommonASTMemberContainer] = {
    complexTypes.map {
      case (name, complexType) => name -> CommonASTTypeContainer(mapMembers(complexType.members))
    }
  }

}
