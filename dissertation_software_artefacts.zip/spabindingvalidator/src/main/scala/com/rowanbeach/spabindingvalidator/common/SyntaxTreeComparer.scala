package com.rowanbeach.spabindingvalidator.common

object SyntaxTreeComparer {

  private def typesAreCompatible(typeScriptType: CommonASTLeafNode, bindingType: CommonASTLeafNode): Boolean = {
    // TODO - refine rules for deciding if types are compatible as required
    // This could be based on both SPA specific binding declarations and data type specific HTML5 input types
    typeScriptType == bindingType || {
      val typePair = (typeScriptType, bindingType)
      typePair match {
        case (CommonASTString | CommonASTNumber, CommonASTString) => true // A string on the binding side currently represents a text entry field and numbers may be entered into a text entry field
        case _ => false
      }
    }
  }

  def evaluateMatchingResult(matchingContainer: ASTMatchingContainer): Boolean = matchingContainer.members.forall({
    case (_, comparisonResult: ASTMatchingContainer) => evaluateMatchingResult(comparisonResult) // recursive call
    case (_, comparisonResult: ASTNodeComparisonSuccess) => true
    case _ => false
  })

  /**
   * This will generate failures for unmatched elements
   */
  def compareViewToModel(markupASTContainer: CommonASTMemberContainer, typeScriptASTContainer: CommonASTMemberContainer): ASTMatchingContainer = {

    ASTMatchingContainer(typeScriptASTContainer, markupASTContainer,

      markupASTContainer.members.map {

        case (bindingName: String, bindingType: CommonASTMemberContainer) => (bindingName,
          typeScriptASTContainer(bindingName) match {
            case None => ASTMissingViewModelContainerNodeComparisonResult(bindingType)
            case Some(typeScriptType: CommonASTMemberContainer) => compareViewToModel(bindingType, typeScriptType) // recursive call to descend tree
            case Some(typeScriptType: CommonASTLeafNode) => ASTLeafNodeFoundInModelWhenExpectingContainerNodeComparisonResult(typeScriptType, bindingType)
            case Some(typeScriptType) => ASTUnexpectedComparisonResult(typeScriptType, bindingType)
          })

        case (bindingName: String, bindingType: CommonASTLeafNode) => (bindingName,
          typeScriptASTContainer(bindingName) match {
            case None => ASTMissingViewModelLeafNodeComparisonResult(bindingType)
            case Some(typeScriptType: CommonASTMemberContainer) => ASTContainerNodeFoundInModelWhenExpectingLeafNodeComparisonResult(typeScriptType, bindingType)
            case Some(typeScriptType: CommonASTLeafNode) =>
              if (typesAreCompatible(typeScriptType, bindingType)) ASTMatchingLeafNodeComparisonResult(typeScriptType, bindingType)
              else ASTNonMatchingNodeTypeComparisonResult(typeScriptType, bindingType)
            case Some(typeScriptType) => ASTUnexpectedComparisonResult(typeScriptType, bindingType)
          })

      })

  }

  /**
   * This will generate warnings for unmatched elements
   */
  def compareModelToView(typeScriptASTContainer: CommonASTMemberContainer, markupASTContainer: CommonASTMemberContainer): ASTMatchingContainer = {

    ASTMatchingContainer(markupASTContainer, typeScriptASTContainer,

      typeScriptASTContainer.members.map {

        case (typeScriptMemberName: String, typeScriptType: CommonASTMemberContainer) => (typeScriptMemberName,
          markupASTContainer(typeScriptMemberName) match {
            case None => Some(ASTUnusedViewModelContainerNodeComparisonResult(typeScriptType))
            case Some(markupType: CommonASTMemberContainer) => Some(compareModelToView(typeScriptType, markupType)) // recursive call to descend tree
            case Some(otherMarkupType) => None
          })

        case (typeScriptMemberName: String, typeScriptType) => (typeScriptMemberName,
          markupASTContainer(typeScriptMemberName) match {
            case None => Some(ASTUnusedViewModelLeafNodeComparisonResult(typeScriptType))
            case Some(markupType) => None
          })

      }.collect({
        // Filter out Nones
        case (typeScriptMemberName, Some(cr)) => (typeScriptMemberName, cr)
      }))

  }

}

trait ASTNodeComparisonResult

trait ASTNodeComparisonSuccess extends ASTNodeComparisonResult

trait ASTNodeComparisonWarning extends ASTNodeComparisonResult

trait ASTNodeComparisonFailure extends ASTNodeComparisonResult

case class ASTMatchingContainer(typeScriptNode: CommonASTMemberContainer, markupNode: CommonASTMemberContainer, members: Map[String, ASTNodeComparisonResult]) extends ASTNodeComparisonSuccess with MemberContainer {
  override val toString = "container"
}

case class ASTMatchingLeafNodeComparisonResult(typeScriptNode: CommonASTLeafNode, markupNode: CommonASTLeafNode) extends ASTNodeComparisonSuccess

case class ASTMissingViewModelContainerNodeComparisonResult(markupNode: CommonASTMemberContainer) extends ASTNodeComparisonFailure {
  override val toString = s"Missing container node: binding was declared in the view but there is no corresponding node in the viewmodel"
}

case class ASTMissingViewModelLeafNodeComparisonResult(markupNode: CommonASTType) extends ASTNodeComparisonFailure {
  override val toString = s"Missing leaf node: binding was declared in the view but there is no corresponding node in the viewmodel"
}

case class ASTLeafNodeFoundInModelWhenExpectingContainerNodeComparisonResult(typeScriptNode: CommonASTLeafNode, markupNode: CommonASTMemberContainer) extends ASTNodeComparisonFailure {
  override val toString = s"A leaf node of type $typeScriptNode was found in the model when the binding declaration in the view describes a container node of type $markupNode"
}

case class ASTContainerNodeFoundInModelWhenExpectingLeafNodeComparisonResult(typeScriptNode: CommonASTMemberContainer, markupNode: CommonASTLeafNode) extends ASTNodeComparisonFailure {
  override val toString = s"A container node of type $typeScriptNode was found in the model when the binding declaration in the view describes a leaf node of type $markupNode"
}

case class ASTNonMatchingNodeTypeComparisonResult(typeScriptNode: CommonASTType, markupNode: CommonASTType) extends ASTNodeComparisonFailure {
  override val toString = s"Non-matching node type: binding of type $markupNode was declared in the view but the type of the corresponding node in the model is $typeScriptNode"
}

case class ASTUnusedViewModelContainerNodeComparisonResult(typeScriptNode: CommonASTMemberContainer) extends ASTNodeComparisonWarning {
  override val toString = s"Unused container node: container node was declared in the viewmodel but is not bound in the view"
}

case class ASTUnusedViewModelLeafNodeComparisonResult(typeScriptNode: CommonASTType) extends ASTNodeComparisonWarning {
  override val toString = s"Unused leaf node: node was declared in the viewmodel but is not bound in the view"
}

case class ASTUnexpectedComparisonResult(typeScriptNode: CommonASTType, markupNode: CommonASTType) extends ASTNodeComparisonFailure {
  override val toString = s"Unexpected comparison result - typeScriptNode $typeScriptNode was neither a CommonASTMemberContainer nor a CommonASTPrimitiveType - this shouldn't happen at runtime"
}


