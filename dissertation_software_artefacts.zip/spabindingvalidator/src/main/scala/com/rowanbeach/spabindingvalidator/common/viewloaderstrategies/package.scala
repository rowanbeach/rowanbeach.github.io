package com.rowanbeach.spabindingvalidator.common

import java.io.File

package object viewFileStrategies {

  private def getViewContentFromFile(viewPath: String): String = {
    val source = scala.io.Source.fromFile(viewPath)
    val fileContents = source.mkString
    source.close()
    fileContents
  }

  def allFilesInDirectory(baseDirectory: String): List[(String, String)] = {
    val filenames = new File(baseDirectory).listFiles((_: File, path: String) => path.endsWith(".html")).map(_.getCanonicalPath).toList
    filenames.map(viewPath => (viewPath, getViewContentFromFile(viewPath)))
  }

  def singleFile(path: String): List[(String, String)] = {
    val canonicalPath = new File(path).getCanonicalPath
    List((canonicalPath, getViewContentFromFile(canonicalPath)))
  }

}
