package com.rowanbeach.spabindingvalidator.common

import scala.annotation.tailrec

object CommonASTUtils {

  def resolveViewModelRootFromDottedName(viewModelRoot: CommonASTMemberContainer, dottedName: String): Option[CommonASTMemberContainer] = {

    @tailrec
    def inner(viewModelNode: CommonASTMemberContainer, rootList: List[String]): Option[CommonASTMemberContainer] = rootList match {
      case Nil => None
      case head :: Nil => viewModelNode(head) match {
        case Some(x: CommonASTMemberContainer) => Some(x)
        case _ => None
      }
      case head :: tail =>
        viewModelNode(head) match {
          case Some(matchedNode: CommonASTMemberContainer) => inner(matchedNode, tail)
          case _ => None
        }
    }

    inner(viewModelRoot, dottedName.split('.').toList)

  }

}
