package com.rowanbeach.spabindingvalidator.typescript

import java.io.File

import com.rowanbeach.spabindingvalidator.common._
import org.scalatest._

class TypeScriptCommonASTBuilderSpec extends FunSpec with Matchers {

  describe("When building a common AST model") {

    describe("using IContactViewModel.ts") {

      val file = new File(getClass.getResource("/IContactViewModel.ts").getFile)
      val commonAST: Map[String, CommonASTType] = TypeScriptCommonASTBuilder.buildSyntaxTrees(file.getPath, file.getName :: Nil, StandardTypeScriptTypeSignatureParser)

      it("a typescript string array should be parsed correctly") {
        commonAST.get("testFiles.viewmodels.IContactViewModel")
          .flatMap({ case c: CommonASTTypeContainer => c("allFirstNames") }) should equal(Some(CommonASTStringArray))
      }

      it("a typescript reference type array should be parsed correctly") {
        commonAST.get("testFiles.viewmodels.IContactViewModel")
          .flatMap({ case c: CommonASTTypeContainer => c("allNames") }) should equal(Some(CommonASTTypeContainerArray(Map("firstName" -> CommonASTString, "lastName" -> CommonASTString))))
      }

    }

    describe("using ISupplierListViewModel.ts") {

      val file = new File(getClass.getResource("/ISupplierListViewModel.ts").getFile)
      val commonASTModels: Map[String, CommonASTMemberContainer] = TypeScriptCommonASTBuilder.buildSyntaxTrees(file.getPath, file.getName :: Nil, StandardTypeScriptTypeSignatureParser)

      it("a generically typed typescript property based on a primitive type should be parsed correctly") {

        (for {
          viewModel <- commonASTModels.get("rb.viewmodels.SupplierListViewModel")
          genericProperty <- viewModel.getChildContainer("primitiveGenericProperty")
          item <- genericProperty("firstItem")
        } yield item) should equal(Some(CommonASTNumber))

      }

      it("a generically typed typescript property based on a primitive type array should be parsed correctly") {

        (for {
          viewModel <- commonASTModels.get("rb.viewmodels.SupplierListViewModel")
          genericProperty <- viewModel.getChildContainer("primitiveGenericProperty")
          item <- genericProperty("items")
        } yield item) should equal(Some(CommonASTNumberArray))

      }

      it("a generically typed typescript property based on a type container should be parsed correctly") {

        (for {
          viewModel <- commonASTModels.get("rb.viewmodels.SupplierListViewModel")
          containerGenericProperty <- viewModel.getChildContainer("containerGenericProperty")
          item <- containerGenericProperty("firstItem")
        } yield item) should equal(Some(CommonASTTypeContainer(Map("companyName" -> CommonASTString))))

      }

      it("a generically typed typescript property based on a type container array should be parsed correctly") {

        (for {
          viewModel <- commonASTModels.get("rb.viewmodels.SupplierListViewModel")
          containerGenericProperty <- viewModel.getChildContainer("containerGenericProperty")
          item <- containerGenericProperty("items")
        } yield item) should equal(Some(CommonASTTypeContainerArray(Map("companyName" -> CommonASTString))))

      }

      it("a nested generically typed typescript property based on a type container and a primitive type should be parsed correctly") {

        val c = for {
          viewModel <- commonASTModels.get("rb.viewmodels.SupplierListViewModel")
          containerGenericProperty <- viewModel.getChildContainer("primitiveGenericProperty")
          customer <- containerGenericProperty.getChildContainer("customer")
        } yield customer

        c.get.apply("thingA") should equal(Some(CommonASTString))
        c.get.apply("thingB") should equal(Some(CommonASTNumber))

      }

      it("a nested generically typed typescript property with both nested parts based on a type container should be parsed correctly") {

        val c = for {
          viewModel <- commonASTModels.get("rb.viewmodels.SupplierListViewModel")
          containerGenericProperty <- viewModel.getChildContainer("containerGenericProperty")
          customer <- containerGenericProperty.getChildContainer("customer")
        } yield customer

        c.get.apply("thingA") should equal(Some(CommonASTString))
        c.get.apply("thingB") should equal(Some(CommonASTTypeContainer(Map("companyName" -> CommonASTString))))

      }

    }

  }

}
