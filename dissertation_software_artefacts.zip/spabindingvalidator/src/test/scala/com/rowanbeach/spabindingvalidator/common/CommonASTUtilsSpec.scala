package com.rowanbeach.spabindingvalidator.common

import com.rowanbeach.spabindingvalidator.TestUtils.stc
import org.scalatest._

class CommonASTUtilsSpec extends FlatSpec with Matchers {

  "resolving against an empty matching container with an empty string" should "return None" in {
    CommonASTUtils.resolveViewModelRootFromDottedName(stc(), "") should equal(None)
  }

  "resolving against a non-empty matching container with an empty string" should "return None" in {
    CommonASTUtils.resolveViewModelRootFromDottedName(stc("foo" -> stc()), "") should equal(None)
  }

  "resolving an existing named container at the root" should "return the container" in {
    CommonASTUtils.resolveViewModelRootFromDottedName(stc("foo" -> stc()), "foo") should equal(Some(stc()))
  }

  "resolving an existing named container at a deeper level in the hierarchy" should "return the container" in {
    CommonASTUtils.resolveViewModelRootFromDottedName(stc("foo" -> stc("bar" -> stc("baz" -> stc("a" -> CommonASTString, "b" -> CommonASTString)))), "foo.bar.baz") should equal(
      Some(stc("a" -> CommonASTString, "b" -> CommonASTString))
    )
  }

  /**
   * The viewmodel needs to be a container, it cannot be a primitive type
   */
  "resolving an existing named string at a deeper level in the hierarchy" should "return the string" in {
    CommonASTUtils.resolveViewModelRootFromDottedName(stc("foo" -> stc("bar" -> stc("baz" -> CommonASTString))), "foo.bar.baz") should equal(None)
  }

  "resolving a non-existing named container" should "return None" in {
    CommonASTUtils.resolveViewModelRootFromDottedName(stc("foo" -> stc("bar" -> stc("baz" -> stc("a" -> CommonASTString, "b" -> CommonASTString)))), "not.here") should equal(None)
  }

}