package com.rowanbeach.spabindingvalidator.bindingmarkup.spaframeworks.angularjs

import com.rowanbeach.spabindingvalidator.bindingmarkup.BindingMarkupNodeCommonASTBuilder
import com.rowanbeach.spabindingvalidator.common.CommonASTString
import com.rowanbeach.spabindingvalidator.TestUtils._
import org.scalatest._

class AngularJSBindingMarkupCommonASTBuilderSpec extends FunSpec with Matchers {

  describe("buildSyntaxTree") {

    describe("for markup with a single attribute binding") {
      it("should be built correctly") {
        val x = BindingMarkupNodeCommonASTBuilder.buildSyntaxTree( """<input type="text" ng-model="name"/>""", AngularJSParsingStrategy)
        x should equal(stc("name" -> CommonASTString))
      }
    }

    describe("for markup with a single inline binding") {
      it("should be built correctly") {
        BindingMarkupNodeCommonASTBuilder.buildSyntaxTree( """<span>{{title}}</span>""", AngularJSParsingStrategy) should equal(stc("title" -> CommonASTString))
      }
    }

    describe("for markup with a multi-part attribute binding") {
      it("should be built correctly") {
        BindingMarkupNodeCommonASTBuilder.buildSyntaxTree( """<input type="text" ng-model="customer.name"/>""", AngularJSParsingStrategy) should equal(stc("customer" -> stc("name" -> CommonASTString)))
      }
    }

    describe("for markup with a multi-part inline binding") {
      it("should be built correctly") {
        BindingMarkupNodeCommonASTBuilder.buildSyntaxTree( """<span>{{customer.title}}</span>""", AngularJSParsingStrategy) should equal(stc("customer" -> stc("title" -> CommonASTString)))
      }
    }

    describe("for markup with several inline bindings") {
      describe("in the same text block") {
        it("should be built correctly") {
          BindingMarkupNodeCommonASTBuilder.buildSyntaxTree( """<li>{{firstName}} - {{lastName}} - {{address.line1}} - {{address.line2}}</li>""", AngularJSParsingStrategy) should equal(
            stc("firstName" -> CommonASTString, "lastName" -> CommonASTString, "address" -> stc("line1" -> CommonASTString, "line2" -> CommonASTString))
          )
        }
      }

      describe("on different lines in the same text block") {
        it("should be built correctly") {

          BindingMarkupNodeCommonASTBuilder.buildSyntaxTree( """<li>
        {{firstName}} -
        {{lastName}} -
        {{address.line1}} -
        {{address.line2}}
        </li>""".stripMargin, AngularJSParsingStrategy) should equal(stc("firstName" -> CommonASTString, "lastName" -> CommonASTString, "address" -> stc("line1" -> CommonASTString, "line2" -> CommonASTString)))

        }
      }
    }

  }

}
