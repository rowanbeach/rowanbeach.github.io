package com.rowanbeach.spabindingvalidator.bindingmarkup.spaframeworks.durandal

import com.rowanbeach.spabindingvalidator.bindingmarkup.{HTMLSimpleBindingContextName, BindingMarkupNodeCommonASTBuilder}
import com.rowanbeach.spabindingvalidator.common.{CommonASTBoolean, CommonASTString}
import com.rowanbeach.spabindingvalidator.TestUtils._
import org.scalatest._

class DurandalBindingMarkupCommonASTBuilderSpec extends FunSpec with Matchers {

  val sb = HTMLSimpleBindingContextName

  describe("buildSyntaxTree") {

    describe("for markup with a single text binding") {

      it("should be built correctly") {

        BindingMarkupNodeCommonASTBuilder.buildSyntaxTree( """<span data-bind="text: firstName"></span>""", DurandalParsingStrategy) should equal(stc("firstName" -> CommonASTString))

      }
    }

    describe("for markup with a single binding with a non-standard type hint") {

      it("should be built correctly") {

        BindingMarkupNodeCommonASTBuilder.buildSyntaxTree( """<span data-bind="visible: firstName"></span>""", DurandalParsingStrategy) should equal(stc("firstName" -> CommonASTBoolean))

      }
    }

    describe("for markup with a single namespaced text binding") {

      it("should be built correctly") {

        BindingMarkupNodeCommonASTBuilder.buildSyntaxTree( """<span data-bind="text: customer.firstName"></span>""", DurandalParsingStrategy) should equal(stc("customer" -> stc("firstName" -> CommonASTString)))

      }
    }

    describe("for markup with a multi part binding") {

      it("should be built correctly") {

        BindingMarkupNodeCommonASTBuilder.buildSyntaxTree( """<span data-bind="attr: { href: url, title: details }"></span>""", DurandalParsingStrategy) should equal(stc("url" -> CommonASTString, "details" -> CommonASTString))

      }
    }

    describe("for markup with a multi part namespaced binding") {

      it("should be built correctly") {

        BindingMarkupNodeCommonASTBuilder.buildSyntaxTree( """<span data-bind="attr: { href: customer.url, title: details }"></span>""", DurandalParsingStrategy) should equal(stc("customer" -> stc("url" -> CommonASTString), "details" -> CommonASTString))

      }
    }

    describe("for markup with a \"with\" attribute binding") {

      it("should be built correctly") {

        BindingMarkupNodeCommonASTBuilder.buildSyntaxTree( """<div data-bind="with: foo"><input type="text" data-bind="model: bar"/></div>""", DurandalParsingStrategy) should equal(stc("foo" -> stc("bar" -> CommonASTString)))

      }
      
    }

    describe("for markup with a nested \"with\" attribute binding") {

      it("should be built correctly") {

        BindingMarkupNodeCommonASTBuilder.buildSyntaxTree( """<div data-bind="with: foo"><div data-bind="with: bar"><input type="text" data-bind="model: baz"/></div></div>""", DurandalParsingStrategy) should equal(
          stc("foo" -> stc("bar" -> stc("baz" -> CommonASTString)))
        )

      }

    }

    describe("for markup with a \"foreach\" attribute binding") {


      it("should be built correctly") {

        BindingMarkupNodeCommonASTBuilder.buildSyntaxTree( """<div data-bind="foreach: customers"><input type="text" data-bind="value: firstName"><input type="text" data-bind="value: lastName"></div>""", DurandalParsingStrategy) should equal(
          stc("customers" -> atc("firstName" -> CommonASTString, "lastName" -> CommonASTString))
        )

      }

    }

  }

}
