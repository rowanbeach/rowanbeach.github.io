package com.rowanbeach.spabindingvalidator.typescript

import org.scalatest._
import org.scalatest.prop.TableDrivenPropertyChecks._

class TypeScriptTypeSignatureParserSpec extends FunSpec with Matchers {

  def tr(typeName: String) = TypeScriptSimpleTypeRef(typeName, "", "", Nil)

  def tr(typeName: String, declaringContainerNamespace: String, relativeNamespace: String) = TypeScriptSimpleTypeRef(typeName, declaringContainerNamespace, relativeNamespace, Nil)

  def tra(typeName: String) = TypeScriptArrayTypeRef(typeName, "", "", Nil)

  def tra(typeName: String, declaringContainerNamespace: String, relativeNamespace: String) = TypeScriptArrayTypeRef(typeName, declaringContainerNamespace, relativeNamespace, Nil)

  def gtr(typeName: String, typeParams: TypeScriptType*) = TypeScriptSimpleTypeRef(typeName, "", "", typeParams.toList)

  def gtr(typeName: String, declaringContainerNamespace: String, relativeNamespace: String, typeParams: TypeScriptType*) = TypeScriptSimpleTypeRef(typeName, declaringContainerNamespace, relativeNamespace, typeParams.toList)

  def gta(typeName: String, typeParams: TypeScriptType*) = TypeScriptArrayTypeRef(typeName, "", "", typeParams.toList)

  def gta(typeName: String, declaringContainerNamespace: String, relativeNamespace: String, typeParams: TypeScriptType*) = TypeScriptArrayTypeRef(typeName, declaringContainerNamespace, relativeNamespace, typeParams.toList)

  describe("parse") {

    describe("with no container namespace") {

      val typeSignatures =
        Table(
          ("typeSignature", "expectedResult"),
          ("string", TypeScriptString),
          ("number", TypeScriptNumber),
          ("boolean", TypeScriptBoolean),
          ("Date", TypeScriptDate),
          ("void", TypeScriptVoid),
          ("string[]", TypeScriptStringArray),
          ("number[]", TypeScriptNumberArray),
          ("Foo[]", tra("Foo")),
          ("Foo []", tra("Foo")),
          ("Foo", tr("Foo")),
          ("bar.Foo", tr("Foo", "", "bar")),
          ("Foo<string>", gtr("Foo", TypeScriptString)),
          ("Foo<string, number>", gtr("Foo", TypeScriptString, TypeScriptNumber)),
          ("Foo<number>", gtr("Foo", TypeScriptNumber)),
          ("Foo<Bar>", gtr("Foo", tr("Bar"))),
          ("Foo<Bar>[]", gta("Foo", tr("Bar"))),
          ("Foo<Bar[]>", gtr("Foo", tra("Bar"))),
          ("Foo<Bar<Baz>>", gtr("Foo", gtr("Bar", tr("Baz")))),
          ("Foo<Bar<Baz, string>, number>", gtr("Foo", gtr("Bar", tr("Baz"), TypeScriptString), TypeScriptNumber)),
          ("Foo<bob.bill.Bar<Baz, string>, number>", gtr("Foo", gtr("Bar", "", "bob.bill", tr("Baz"), TypeScriptString), TypeScriptNumber)),
          ("Foo<Bar<Baz, string>, number[]>", gtr("Foo", gtr("Bar", tr("Baz"), TypeScriptString), TypeScriptNumberArray)),
          ("apps.IPagedList<ISupplierListItem>", gtr("IPagedList", "", "apps", tr("ISupplierListItem"))),
          ("apps.IPagedList<test123.ISupplierListItem>", gtr("IPagedList", "", "apps", tr("ISupplierListItem", "", "test123"))),
          ("() => void", TypeScriptFunction(TypeScriptVoid)),
          ("() => string", TypeScriptFunction(TypeScriptString)),
          ("() => Foo", TypeScriptFunction(tr("Foo")))
        )


      forAll(typeSignatures) { (typeSignature: String, expectedResult: TypeScriptType) =>
        it("should correctly parse a type signature of " + typeSignature) {
          StandardTypeScriptTypeSignatureParser.parse(typeSignature, "") should equal(expectedResult)
        }
      }

    }

    describe("for a type reference with a declaring container namespace of \"test\"") {

      val typeSignatures =
        Table(
          ("typeSignature", "expectedResult"),
          ("Foo[]", tra("Foo", "test", "")),
          ("Foo []", tra("Foo", "test", "")),
          ("Foo", tr("Foo", "test", "")),
          ("bar.Foo", tr("Foo", "test", "bar")),
          ("Foo<string>", gtr("Foo", "test", "", TypeScriptString)),
          ("Foo<string, number>", gtr("Foo", "test", "", TypeScriptString, TypeScriptNumber)),
          ("Foo<number>", gtr("Foo", "test", "", TypeScriptNumber)),
          ("Foo<Bar>", gtr("Foo", "test", "", tr("Bar", "test", ""))),
          ("Foo<Bar>[]", gta("Foo", "test", "", tr("Bar", "test", ""))),
          ("Foo<Bar[]>", gtr("Foo", "test", "", tra("Bar", "test", ""))),
          ("Foo<Bar<Baz>>", gtr("Foo", "test", "", gtr("Bar", "test", "", tr("Baz", "test", "")))),
          ("Foo<Bar<Baz, string>, number>", gtr("Foo", "test", "", gtr("Bar", "test", "", tr("Baz", "test", ""), TypeScriptString), TypeScriptNumber)),
          ("Foo<bob.bill.Bar<Baz, string>, number>", gtr("Foo", "test", "", gtr("Bar", "test", "bob.bill", tr("Baz", "test", ""), TypeScriptString), TypeScriptNumber)),
          ("Foo<Bar<Baz, string>, number[]>", gtr("Foo", "test", "", gtr("Bar", "test", "", tr("Baz", "test", ""), TypeScriptString), TypeScriptNumberArray)),
          ("apps.IPagedList<ISupplierListItem>", gtr("IPagedList", "test", "apps", tr("ISupplierListItem", "test", ""))),
          ("apps.IPagedList<test123.ISupplierListItem>", gtr("IPagedList", "test", "apps", tr("ISupplierListItem", "test", "test123")))
        )

      forAll(typeSignatures) { (typeSignature: String, expectedResult: TypeScriptType) =>
        it("should correctly parse a type signature of " + typeSignature) {
          StandardTypeScriptTypeSignatureParser.parse(typeSignature, "test") should equal(expectedResult)
        }
      }

    }

  }


}