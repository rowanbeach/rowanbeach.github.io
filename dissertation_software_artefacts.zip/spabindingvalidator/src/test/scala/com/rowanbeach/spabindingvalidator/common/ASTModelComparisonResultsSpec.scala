package com.rowanbeach.spabindingvalidator.common

import com.rowanbeach.spabindingvalidator.common.ASTModelComparisonResults.{FoundASTModelComparisonResult, NotFoundASTModelComparisonResult}
import com.rowanbeach.spabindingvalidator.TestUtils.stc
import org.scalatest._

class ASTModelComparisonResultsSpec extends FlatSpec with Matchers {

  "success for a NotFoundASTModelComparisonResult" should "return false" in {
    NotFoundASTModelComparisonResult("", "").isSuccessful should equal(false)
  }

  "success for a FoundASTModelComparisonResult with empty containers and an empty outside list" should "return true" in {
    FoundASTModelComparisonResult("", "", ASTMatchingContainer(stc(), stc(), Map()), ASTMatchingContainer(stc(), stc(), Map()), Nil).isSuccessful should equal(true)
  }

  "success for a FoundASTModelComparisonResult with a non-empty outside list" should "return false" in {
    FoundASTModelComparisonResult("", "", ASTMatchingContainer(stc(), stc(), Map()), ASTMatchingContainer(stc(), stc(), Map()), List("foo" -> CommonASTString)).isSuccessful should equal(false)
  }

  "success for a FoundASTModelComparisonResult with no errors in the view -> model matching list" should "return true" in {
    FoundASTModelComparisonResult("", "", ASTMatchingContainer(stc(), stc(), Map("foo" -> ASTMatchingLeafNodeComparisonResult(CommonASTString, CommonASTString))), ASTMatchingContainer(stc(), stc(), Map()), Nil).isSuccessful should equal(true)
  }

  "success for a FoundASTModelComparisonResult with errors in the view -> model matching list" should "return false" in {
    FoundASTModelComparisonResult("", "", ASTMatchingContainer(stc(), stc(), Map("foo" -> ASTNonMatchingNodeTypeComparisonResult(CommonASTString, CommonASTDate))), ASTMatchingContainer(stc(), stc(), Map()), Nil).isSuccessful should equal(false)
  }

  "success for a FoundASTModelComparisonResult with warnings in the model -> view matching list" should "return true" in {
    FoundASTModelComparisonResult("", "", ASTMatchingContainer(stc(), stc(), Map()), ASTMatchingContainer(stc(), stc(), Map("foo" -> ASTUnusedViewModelLeafNodeComparisonResult(CommonASTString))), Nil).isSuccessful should equal(true)
  }

}