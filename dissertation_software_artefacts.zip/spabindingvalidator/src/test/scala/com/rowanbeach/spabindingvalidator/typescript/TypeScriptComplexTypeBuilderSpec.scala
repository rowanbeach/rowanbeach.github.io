package com.rowanbeach.spabindingvalidator.typescript

import org.scalatest._
import com.rowanbeach.spabindingvalidator.TestUtils._

class TypeScriptComplexTypeBuilderSpec extends FunSpec with Matchers {

  describe("TypeScriptTypeConstructorHierarchyBuilder") {

    describe("A type map with an unresolvable type reference") {

      val result = TypeScriptModule(TypeScriptComplexTypeBuilder.buildFrom(Map(
        "test.viewmodels.Session" -> ngt(
          "foo" -> TypeScriptString,
          "currentSession" -> TypeScriptSimpleTypeRef("IExternalSession", "bob.jones", "test.viewmodels", Nil)))))

      val session = result.getComplexType("test.viewmodels.Session")

      it("should have a complex type at test.viewmodels.Session") {
        session.isDefined should equal(true)
      }

      if (session.isDefined) {
        describe("and the complex type") {
          it("should have a string at foo") {
            session.get("foo") should equal(Some(TypeScriptString))
          }
          it("should have an unresolved type reference at currentSession") {
            session.get("currentSession") should equal(Some(TypeScriptUnresolvedTypeReference("IExternalSession")))
          }
        }
      }

    }

    describe("A type map with a local resolvable type reference at the same level") {

      val result = TypeScriptModule(TypeScriptComplexTypeBuilder.buildFrom(Map(
        "test.viewmodels.Session" -> ngt("foo" -> TypeScriptString, "currentSession" -> TypeScriptSimpleTypeRef("ISession", "", "test.viewmodels", Nil)),
        "test.viewmodels.ISession" -> ngt("a" -> TypeScriptString))))

      val session = result.getComplexType("test.viewmodels.Session")

      it("should have a complex type at test.viewmodels.Session") {
        session.isDefined should equal(true)
      }

      if (session.isDefined) {
        describe("and the complex type") {
          it("should have a string at foo") {
            session.get("foo") should equal(Some(TypeScriptString))
          }
          it("should have a resolved type reference at currentSession") {
            session.get("currentSession") should equal(Some(ngt("a" -> TypeScriptString)))
          }
        }
      }

    }

    describe("A type map with a local resolvable type reference at a deeper level") {

      val result = TypeScriptModule(TypeScriptComplexTypeBuilder.buildFrom(Map(
        "test.viewmodels.Session" -> ngt("foo" -> TypeScriptString, "currentSession" -> TypeScriptSimpleTypeRef("ISession", "test.viewmodels", "deeperLevel", Nil)),
        "test.viewmodels.deeperLevel.ISession" -> ngt("a" -> TypeScriptString))))

      val session = result.getComplexType("test.viewmodels.Session")

      it("should have a complex type at test.viewmodels.Session") {
        session.isDefined should equal(true)
      }

      if (session.isDefined) {
        describe("and the complex type") {
          it("should have a string at foo") {
            session.get("foo") should equal(Some(TypeScriptString))
          }
          it("should have a resolved type reference at currentSession") {
            session.get("currentSession") should equal(Some(ngt("a" -> TypeScriptString)))
          }
        }
      }

    }

    describe("A type map with a local resolvable type reference at a higher level") {

      val result = TypeScriptModule(TypeScriptComplexTypeBuilder.buildFrom(Map(
        "test.viewmodels.Session" -> ngt("foo" -> TypeScriptString, "currentSession" -> TypeScriptSimpleTypeRef("ISession", "test.viewmodels", "", Nil)),
        "test.ISession" -> ngt("a" -> TypeScriptString))))

      val session = result.getComplexType("test.viewmodels.Session")

      it("should have a complex type at test.viewmodels.Session") {
        session.isDefined should equal(true)
      }

      if (session.isDefined) {
        describe("and the complex type") {
          it("should have a string at foo") {
            session.get("foo") should equal(Some(TypeScriptString))
          }
          it("should have a resolved type reference at currentSession") {
            session.get("currentSession") should equal(Some(ngt("a" -> TypeScriptString)))
          }
        }
      }

    }

    describe("A type map with a matching local resolvable type reference at the same level and at a higher level") {

      val result = TypeScriptModule(TypeScriptComplexTypeBuilder.buildFrom(Map(
        "test.viewmodels.Session" -> ngt("foo" -> TypeScriptString, "currentSession" -> TypeScriptSimpleTypeRef("ISession", "", "test.viewmodels", Nil)),
        "test.viewmodels.ISession" -> ngt("theCorrectSession" -> TypeScriptString),
        "test.ISession" -> ngt("theWrongSession" -> TypeScriptString))))

      val session = result.getComplexType("test.viewmodels.Session")

      it("should have a complex type at test.viewmodels.Session") {
        session.isDefined should equal(true)
      }

      if (session.isDefined) {
        describe("and the complex type") {
          it("should have a string at foo") {
            session.get("foo") should equal(Some(TypeScriptString))
          }
          it("should have the correct local resolved type reference at currentSession") {
            session.get("currentSession") should equal(Some(ngt("theCorrectSession" -> TypeScriptString)))
          }
        }
      }

    }

    describe("A type map with an array of primitive type") {

      val result = TypeScriptModule(TypeScriptComplexTypeBuilder.buildFrom(Map(
        "test.viewmodels.Session" -> ngt("foo" -> TypeScriptString, "currentSession" -> TypeScriptStringArray))))

      val session = result.getComplexType("test.viewmodels.Session")

      it("should have a complex type at test.viewmodels.Session") {
        session.isDefined should equal(true)
      }

      if (session.isDefined) {
        describe("and the complex type") {
          it("should have a string at foo") {
            session.get("foo") should equal(Some(TypeScriptString))
          }
          it("should have a string array at currentSession") {
            session.get("currentSession") should equal(Some(TypeScriptStringArray))
          }
        }
      }

    }

    describe("A type map with an array of a local resolvable type reference") {

      val result = TypeScriptModule(TypeScriptComplexTypeBuilder.buildFrom(Map(
        "test.viewmodels.Session" -> ngt("foo" -> TypeScriptString, "currentSessions" -> TypeScriptArrayTypeRef("ISession", "test.viewmodels", "", Nil)),
        "test.ISession" -> ngt("a" -> TypeScriptString))))

      val session = result.getComplexType("test.viewmodels.Session")

      it("should have a complex type at test.viewmodels.Session") {
        session.isDefined should equal(true)
      }

      if (session.isDefined) {
        describe("and the complex type") {
          it("should have a string at foo") {
            session.get("foo") should equal(Some(TypeScriptString))
          }
          it("should have an ISession array at currentSessions") {
            session.get("currentSessions") should equal(Some(nga("a" -> TypeScriptString)))
          }
        }
      }

    }

    describe("A type map with an external resolvable type reference") {

      val result = TypeScriptModule(TypeScriptComplexTypeBuilder.buildFrom(Map(
        "test.viewmodels.Session" -> ngt("foo" -> TypeScriptString, "currentSession" -> TypeScriptSimpleTypeRef("ISession", "test.viewmodels", "externalSessions", Nil)),
        "externalSessions.ISession" -> ngt("a" -> TypeScriptString))))

      val session = result.getComplexType("test.viewmodels.Session")

      it("should have a complex type at test.viewmodels.Session") {
        session.isDefined should equal(true)
      }

      if (session.isDefined) {
        describe("and the complex type") {
          it("should have a string at foo") {
            session.get("foo") should equal(Some(TypeScriptString))
          }
          it("should have a resolved type reference at currentSession") {
            session.get("currentSession") should equal(Some(ngt("a" -> TypeScriptString)))
          }
        }
      }

    }

    describe("A type map with two level external resolvable type references") {

      val result = TypeScriptModule(TypeScriptComplexTypeBuilder.buildFrom(Map(
        "test.viewmodels.Session" -> ngt("foo" -> TypeScriptString, "currentSession" -> TypeScriptSimpleTypeRef("ISession", "test.viewmodels", "externalSessions", Nil)),
        "externalSessions.ISession" -> ngt("wrongType" -> TypeScriptString),
        "test.externalSessions.ISession" -> ngt("correctType" -> TypeScriptString)))) // This one should be found first

      val session = result.getComplexType("test.viewmodels.Session")

      it("should have a complex type at test.viewmodels.Session") {
        session.isDefined should equal(true)
      }

      if (session.isDefined) {
        describe("and the complex type") {
          it("should have a string at foo") {
            session.get("foo") should equal(Some(TypeScriptString))
          }
          it("should have a resolved type reference at currentSession") {
            session.get("currentSession") should equal(Some(ngt("correctType" -> TypeScriptString)))
          }
        }
      }

    }

    describe("A type map with a local resolvable generic type reference at the same level") {

      val result = TypeScriptModule(TypeScriptComplexTypeBuilder.buildFrom(Map(
        "test.viewmodels.Session" -> ngt("foo" -> TypeScriptString, "currentSession" -> TypeScriptSimpleTypeRef("ISession", "test.viewmodels", "", TypeScriptNumber :: Nil)),
        "test.viewmodels.ISession" -> gt(TypeScriptTypeParameterPlaceholder("A") :: Nil, "a" -> TypeScriptSimpleTypeParameterRef("A")))))

      val session = result.getComplexType("test.viewmodels.Session")

      it("should have a complex type at test.viewmodels.Session") {
        session.isDefined should equal(true)
      }

      if (session.isDefined) {
        describe("and the complex type") {
          it("should have a string at foo") {
            session.get("foo") should equal(Some(TypeScriptString))
          }
          it("should have a resolved type reference at currentSession") {
            session.get("currentSession") should equal(Some(ngt("a" -> TypeScriptNumber)))
          }
        }
      }

    }

    describe("A type map with a local resolvable nested generic type reference at the same level") {

      val result = TypeScriptModule(TypeScriptComplexTypeBuilder.buildFrom(Map(
        "test.viewmodels.Session" -> ngt("foo" -> TypeScriptString, "currentSession" -> TypeScriptSimpleTypeRef("ISession", "test.viewmodels", "", List(TypeScriptSimpleTypeRef("ILocation", "", "test.viewmodels", List(TypeScriptString))))),
        "test.viewmodels.ISession" -> gt(TypeScriptTypeParameterPlaceholder("A") :: Nil, "location" -> TypeScriptSimpleTypeParameterRef("A")),
        "test.viewmodels.ILocation" -> gt(TypeScriptTypeParameterPlaceholder("A") :: Nil, "a" -> TypeScriptSimpleTypeParameterRef("A")))))

      val session = result.getComplexType("test.viewmodels.Session")

      it("should have a complex type at test.viewmodels.Session") {
        session.isDefined should equal(true)
      }

      if (session.isDefined) {
        describe("and the complex type") {
          it("should have a string at foo") {
            session.get("foo") should equal(Some(TypeScriptString))
          }
          it("should have the correct resolved type reference at currentSession") {
            session.get("currentSession") should equal(Some(ngt("location" -> ngt("a" -> TypeScriptString))))
          }
        }
      }

    }

    describe("A type map with a local resolvable type used as a type parameter to an external generic type reference at the same level") {

      val result = TypeScriptModule(TypeScriptComplexTypeBuilder.buildFrom(Map(
        "rb.viewmodels.ISupplierListItem" -> ngt(
          "supplierCode" -> TypeScriptString,
          "companyName" -> TypeScriptString,
          "phone" -> TypeScriptString,
          "active" -> TypeScriptString),
        "rb.viewmodels.SupplierListViewModel" -> ngt(
          "bob" -> TypeScriptString,
          "containerGenericProperty" -> TypeScriptSimpleTypeRef("IPagedList", "rb.viewmodels", "apps", List(TypeScriptSimpleTypeRef("ISupplierListItem", "rb.viewmodels", "", Nil)))),
        "rb.apps.IPagedList" -> gt(List(TypeScriptTypeParameterPlaceholder("T")),
          "pagingMetadata" -> TypeScriptSimpleTypeRef("IPagingMetadata", "rb.viewmodels", "apps", Nil),
          "firstItem" -> TypeScriptSimpleTypeParameterRef("T")),
        "rb.apps.IPagingMetadata" -> ngt(
          "pageNumber" -> TypeScriptNumber,
          "pageCount" -> TypeScriptNumber,
          "pageSize" -> TypeScriptNumber,
          "itemCount" -> TypeScriptNumber)
      )))

      val supplierListViewModel = result.getComplexType("rb.viewmodels.SupplierListViewModel")

      it("should have a complex type at rb.viewmodels.SupplierListViewModel") {
        supplierListViewModel.isDefined should equal(true)
      }

      if (supplierListViewModel.isDefined) {

        describe("and supplierListViewModel") {

          it("should have a string at bob") {
            supplierListViewModel.get.apply("bob") should equal(Some(TypeScriptString))
          }

          val containerGenericProperty = supplierListViewModel.get.getComplexType("containerGenericProperty")

          it("should have a complex type at containerGenericProperty") {
            containerGenericProperty.isDefined should equal(true)
          }

          if (containerGenericProperty.isDefined) {

            describe("and containerGenericProperty") {

              val pagingMetadata = containerGenericProperty.get.getComplexType("pagingMetadata")

              it("should have a complex type at pagingMetadata") {
                pagingMetadata.isDefined should equal(true)
              }

              if (pagingMetadata.isDefined) {

                describe("and pagingMetadata") {

                  it("should have a number at pageNumber") {
                    pagingMetadata.get.apply("pageNumber") should equal(Some(TypeScriptNumber))
                  }

                  it("should have a number at pageCount") {
                    pagingMetadata.get.apply("pageCount") should equal(Some(TypeScriptNumber))
                  }

                  it("should have a number at pageSize") {
                    pagingMetadata.get.apply("pageSize") should equal(Some(TypeScriptNumber))
                  }

                  it("should have a number at itemCount") {
                    pagingMetadata.get.apply("itemCount") should equal(Some(TypeScriptNumber))
                  }

                }


              }

            }
          }

          val firstItem = containerGenericProperty.get.getComplexType("firstItem")

          it("should have a complex type at firstItem") {
            firstItem.isDefined should equal(true)
          }

          if (firstItem.isDefined) {

            describe("and first item") {

              describe("and firstItem") {

                it("should have a string at supplierCode") {
                  firstItem.get.apply("supplierCode") should equal(Some(TypeScriptString))
                }

                it("should have a number at companyName") {
                  firstItem.get.apply("companyName") should equal(Some(TypeScriptString))
                }

                it("should have a number at phone") {
                  firstItem.get.apply("phone") should equal(Some(TypeScriptString))
                }

                it("should have a number at active") {
                  firstItem.get.apply("active") should equal(Some(TypeScriptString))
                }

              }
            }
          }

        }
      }
    }
  }
}
