package com.rowanbeach.spabindingvalidator.bindingmarkup.spaframeworks.angularjs

import com.rowanbeach.spabindingvalidator.bindingmarkup._
import org.scalatest._
import org.scalatest.prop.TableDrivenPropertyChecks._

class AngularParserSpec extends FunSpec with Matchers {

  val sb = HTMLSimpleBindingContextName
  val ab = HTMLArrayBindingContextName

  describe("AngularParsers") {

    describe("parseTextBinding") {

      val testCases =
        Table(
          ("text", "expectedResult"),
          ("{{foo}}", List(List(sb("foo")))),
          ("{{foo.bar}}", List(List(sb("foo"), sb("bar")))),
          ("{{foo.bar}} {{baz}}", List(List(sb("foo"), sb("bar")), List(sb("baz")))),
          ("aaa {{name}}", List(List(sb("name")))),
          (" This is a test... {{blame}}", List(List(sb("blame")))),
          (" {{customer.time}} - {{customer.location}} - {{customer.description}}", List(
            List(sb("customer"), sb("time")),
            List(sb("customer"), sb("location")),
            List(sb("customer"), sb("description"))))
        )

      forAll(testCases) { (typeSignature: String, expectedResult: List[List[HTMLBindingContextName]]) =>
        it("should correctly parse a type signature of " + typeSignature) {
          AngularParser parseBindingContextNameForTextValue typeSignature should equal(expectedResult)
        }
      }

    }

    describe("parseAttributeBinding") {

      val testCases =
        Table(
          ("text", "expectedResult"),
          ("'foo'", Nil),
          ("'foo bar'", Nil),
          ("'foo.bar'", Nil),
          ("'foo_bar'", Nil),
          ("foo", sb("foo") :: Nil),
          ("foo.bar", sb("foo") :: sb("bar") :: Nil),
          ("foo()", sb("foo()") :: Nil),
          ("/#/suppliers/edit/{{item.id}}", sb("item") :: sb("id") :: Nil)
        )

      forAll(testCases) { (typeSignature: String, expectedResult: List[HTMLBindingContextName]) =>
        it("should correctly parse a type signature of " + typeSignature) {
          AngularParser parseBindingContextNameForAttributeValue typeSignature should equal(expectedResult)
        }
      }

    }

    describe("parseChildContextBinding") {

      val testCases =
        Table(
          ("text", "expectedResult"),
          ("customer", List(HTMLSimpleBindingContextName("customer"))),
          ("item in listModel.pagedList.items", List(sb("listModel"), sb("pagedList"), ab("items", "item")))
        )

      forAll(testCases) { (typeSignature: String, expectedResult: List[HTMLBindingContextName]) =>
        it("should correctly parse a type signature of " + typeSignature) {
          AngularParser parseChildContextBindingName typeSignature should equal(expectedResult)
        }
      }

    }

    describe("AngularJSParsingStrategy") {

      describe("parseAttributeBindingValue") {

        describe("for a standard binding") {

          it("should parse correctly") {
            AngularJSParsingStrategy.parseAttributeBindingValue(Nil, "ng-something", "bar") should equal(Some(HTMLBinding(Nil, "bar", HTMLBindingString)))
          }

        }

        describe("for a function binding") {

          it("should parse correctly") {
            AngularJSParsingStrategy.parseAttributeBindingValue(Nil, "ng-something", "bar()") should equal(Some(HTMLBinding(Nil, "bar", HTMLBindingFunction(HTMLBindingVoid))))
          }

        }

      }

    }

  }

}

