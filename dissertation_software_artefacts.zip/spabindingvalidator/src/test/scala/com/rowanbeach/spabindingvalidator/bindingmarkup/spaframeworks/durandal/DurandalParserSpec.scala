package com.rowanbeach.spabindingvalidator.bindingmarkup.spaframeworks.durandal

import com.rowanbeach.spabindingvalidator.bindingmarkup._
import org.scalatest._
import org.scalatest.prop.TableDrivenPropertyChecks._

class DurandalParserSpec extends FunSpec with Matchers {

  val sb = HTMLSimpleBindingContextName
  val ab = HTMLArrayBindingContextName
  def sbl(value: String*): List[HTMLSimpleBindingContextName] = value.map(x => HTMLSimpleBindingContextName(x)).toList
  def hb(value: List[HTMLSimpleBindingContextName], key: String) = HTMLBinding(value, key, HTMLBindingString)

  describe("parse") {

    val testCases =
      Table(
        ("text", "expectedResult"),
        ("with: foo", List(hb(sbl("foo"), "with"))),
        ("visible: foo.bar", List(hb(sbl("foo", "bar"), "visible"))),
        ("with: test", List(hb(sbl("test"), "with"))),
        ("submit: login()", List(hb(sbl("login()"), "submit"))),
        ("attr: { href: url, title: details }", List(hb(sbl("url"), "attr"), hb(sbl("details"), "attr")))
      )

    forAll(testCases) {
      (typeSignature: String, expectedResult: List[HTMLBinding]) => it("should correctly parse a type signature of " + typeSignature) {
        DurandalParser.parse(typeSignature) should equal(expectedResult)
      }
    }
  }

  describe("parseChildContextBinding") {

    val testCases =
      Table(
        ("text", "expectedResult"),
        ("with: customer", List(HTMLSimpleBindingContextName("customer"))),
        ("foreach: listModel.pagedList.items", List(sb("listModel"), sb("pagedList"), ab("items", ""))),
        ("foreach: customers", List(ab("customers", "")))
      )

    forAll(testCases) { (typeSignature: String, expectedResult: List[HTMLBindingContextName]) =>
      it("should correctly parse a type signature of " + typeSignature) {
        DurandalParser parseChildContextBindingName typeSignature should equal(expectedResult)
      }
    }

  }

}