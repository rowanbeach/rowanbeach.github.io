package com.rowanbeach.spabindingvalidator.common

import com.rowanbeach.spabindingvalidator.TestUtils.stc
import org.scalatest._

class ViewModelPartitionerSpec extends FlatSpec with Matchers {

  "partitioning an empty type container" should "result in None, Nil" in {
    ViewModelPartitioningStrategies.accessorPartitioner("")(stc()) should equal (ViewModelPartitioningResult(None, Nil))
  }

  "partitioning a type container with a single member by a non-existing key" should "result in None, and the members from the original type container" in {
    val typeContainer = stc("a" -> CommonASTString)
    ViewModelPartitioningStrategies.accessorPartitioner("x")(typeContainer) should equal (ViewModelPartitioningResult(None, typeContainer.members.toList))
  }

  "partitioning a type container with a single member by an existing key which points to a type container" should "result in the correct type container, and Nil" in {
    val typeContainer = stc("a" -> stc("b" -> CommonASTString))
    ViewModelPartitioningStrategies.accessorPartitioner("a")(typeContainer) should equal (ViewModelPartitioningResult(Some(stc("b" -> CommonASTString)), Nil))
  }

  "partitioning a type container with a single member by an existing key which points to a non-container type" should "result in None, Nil" in {
    val typeContainer = stc("a" -> CommonASTString)
    ViewModelPartitioningStrategies.accessorPartitioner("a")(typeContainer) should equal (ViewModelPartitioningResult(None, Nil))
  }

  "partitioning a type container with multiple members by a non-existing key" should "result in None, and the members from the original type container" in {
    val typeContainer = stc("a" -> CommonASTString, "b" -> stc())
    ViewModelPartitioningStrategies.accessorPartitioner("x")(typeContainer) should equal (ViewModelPartitioningResult(None, typeContainer.members.toList))
  }

  "partitioning a type container with multiple members by an existing key which points to a type container" should "result in the correct type container, and the non-matching members from the original type container" in {
    val typeContainer = stc("a" -> stc("b" -> CommonASTString), "c" -> CommonASTString, "d" -> CommonASTString)
    ViewModelPartitioningStrategies.accessorPartitioner("a")(typeContainer) should equal (ViewModelPartitioningResult(Some(stc("b" -> CommonASTString)), typeContainer.members.toList diff stc("a" -> stc("b" -> CommonASTString)).members.toList))
  }

  "partitioning a type container with multiple members by an existing key which points to a non-container type" should "result in None, and the non-matching members from the original type container" in {
    val typeContainer = stc("a" -> CommonASTString, "c" -> CommonASTString, "d" -> CommonASTString)
    ViewModelPartitioningStrategies.accessorPartitioner("a")(typeContainer) should equal (ViewModelPartitioningResult(None, typeContainer.members.toList diff stc("a" -> CommonASTString).members.toList))
  }

}

