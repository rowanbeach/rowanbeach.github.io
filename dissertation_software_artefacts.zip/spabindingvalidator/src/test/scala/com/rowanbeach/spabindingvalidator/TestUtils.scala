package com.rowanbeach.spabindingvalidator

import com.rowanbeach.spabindingvalidator.common.{CommonASTTypeContainerArray, CommonASTTypeContainer, CommonASTType, CommonASTMemberContainer}
import com.rowanbeach.spabindingvalidator.typescript._

object TestUtils {

  /**
   * Utils to more easily create various types for testing purposes
   */
  def stc(members: (String, CommonASTType)*): CommonASTMemberContainer = CommonASTTypeContainer(members.toMap)

  def atc(members: (String, CommonASTType)*): CommonASTMemberContainer = CommonASTTypeContainerArray(members.toMap)

  def ngt(members: (String, TypeScriptType)*): TypeScriptNonGenericType = TypeScriptNonGenericType(members.toMap)

  def nga(members: (String, TypeScriptType)*): TypeScriptNonGenericTypeArray = TypeScriptNonGenericTypeArray(members.toMap)

  def gt(typeParameters: List[TypeScriptTypeParameterPlaceholder], members: (String, TypeScriptType)*): TypeScriptGenericType = TypeScriptGenericType(typeParameters, members.toMap)

}
