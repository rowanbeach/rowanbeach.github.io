package com.rowanbeach.spabindingvalidator.typescript

import org.scalatest._

class TypeScriptTypesSpec extends FunSpec with Matchers {

  describe("Independently created TypeScriptSimpleTypeRef objects") {

    describe("with no namespace") {

      it("should be equal") {
        TypeScriptSimpleTypeRef("Foo", "", "", Nil) should equal(TypeScriptSimpleTypeRef("Foo", "", "", Nil))
      }

      it("should not be equal") {
        TypeScriptSimpleTypeRef("Foo", "", "", Nil) should not equal TypeScriptSimpleTypeRef("Bar", "", "", Nil)
      }

    }

    describe("with a relative namespace") {

      it("should be equal") {
        TypeScriptSimpleTypeRef("Foo", "com.test", "", Nil) should equal(TypeScriptSimpleTypeRef("Foo", "com.test", "", Nil))
      }

      it("should not be equal") {
        TypeScriptSimpleTypeRef("Foo", "com.test", "", Nil) should not equal TypeScriptSimpleTypeRef("Bar", "com.test2", "", Nil)
      }

    }

  }

}
