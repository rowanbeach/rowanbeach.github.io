package com.rowanbeach.spabindingvalidator.bindingmarkup.spaframeworks.angularjs

import com.rowanbeach.spabindingvalidator.bindingmarkup._
import org.scalatest.{FunSpec, Matchers}

class AngularJSFlatMarkupModelBuilderSpec extends FunSpec with Matchers {

  val sb = HTMLSimpleBindingContextName
  val ab = HTMLArrayBindingContextName

  describe("buildBindingList") {

    describe("with nested binding attributes") {

      describe("for a multi level array binding") {

        describe("with a single level array element prefix") {

          val expected = List(
            HTMLBinding(List(), "gridrow", HTMLBindingString),
            HTMLBinding(List(sb("listModel"), ab("items", "item"), sb("codes")), "supplierCode", HTMLBindingString),
            HTMLBinding(List(sb("listModel"), ab("items", "item")), "companyName", HTMLBindingString),
            HTMLBinding(List(sb("listModel"), ab("items", "item")), "phone", HTMLBindingString),
            HTMLBinding(List(sb("listModel"), ab("items", "item")), "active", HTMLBindingString),
            HTMLBinding(List(sb("listModel"), ab("items", "item")), "id", HTMLBindingString))

          val actual = BindingListBuilder.buildBindingList( """<table><tr ng-repeat="item in listModel.items" ng-class-even="'gridrow_alternate'" ng-class-odd="gridrow">
                                                              |    <td>{{item.codes.supplierCode}}</td>
                                                              |    <td>{{item.companyName}}</td>
                                                              |    <td>{{item.phone}}</td>
                                                              |    <td>{{item.active}}</td>
                                                              |    <td><a ng-href="/#/suppliers/edit/{{item.id}}">details</a></td>
                                                              |</tr></table>""", AngularJSParsingStrategy)

          it("should have the correct length") {
            actual.length should equal(6)
          }

          if (actual.length == 6) {
            it("the first list item should be correct") {
              actual(1) should equal(expected(1))
            }
            it("the second list item should be correct") {
              actual(2) should equal(expected(2))
            }
            it("the third list item should be correct") {
              actual(3) should equal(expected(3))
            }
            it("the fourth list item should be correct") {
              actual(4) should equal(expected(4))
            }
            it("the fifth list item should be correct") {
              actual(5) should equal(expected(5))
            }
          }

        }

      }

    }
  }

}
