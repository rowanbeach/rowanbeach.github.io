package com.rowanbeach.spabindingvalidator.common

import org.scalatest._

class SyntaxTreeComparerSpec extends FlatSpec with Matchers {

  "evaluation of an empty matching container" should "return true" in {
    SyntaxTreeComparer.evaluateMatchingResult(ASTMatchingContainer(null, null, Map())) should equal(true)
  }

  "evaluation of a matching container with a single successful match" should "return true" in {
    SyntaxTreeComparer.evaluateMatchingResult(ASTMatchingContainer(null, null, Map("a" -> ASTMatchingLeafNodeComparisonResult(null, null)))) should equal(true)
  }

  "evaluation of a matching container with a single failing match" should "return false" in {
    SyntaxTreeComparer.evaluateMatchingResult(ASTMatchingContainer(null, null, Map("a" -> ASTNonMatchingNodeTypeComparisonResult(null, null)))) should equal(false)
  }

  "evaluation of a matching container with a container with a single successful match" should "return true" in {
    SyntaxTreeComparer.evaluateMatchingResult(ASTMatchingContainer(null, null, Map("a" -> ASTMatchingContainer(null, null, Map("b" -> ASTMatchingLeafNodeComparisonResult(null, null)))))) should equal(true)
  }

  "evaluation of a matching container with a container with a single successful match" should "return false" in {
    SyntaxTreeComparer.evaluateMatchingResult(ASTMatchingContainer(null, null, Map("a" -> ASTMatchingContainer(null, null, Map("b" -> ASTNonMatchingNodeTypeComparisonResult(null, null)))))) should equal(false)
  }

}
