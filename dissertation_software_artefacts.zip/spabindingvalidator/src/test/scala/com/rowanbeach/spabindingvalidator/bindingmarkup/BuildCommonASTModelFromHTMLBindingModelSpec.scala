package com.rowanbeach.spabindingvalidator.bindingmarkup

import com.rowanbeach.spabindingvalidator.common.{CommonASTVoid, CommonASTFunction, CommonASTString, CommonASTTypeContainer}
import org.scalatest.{FunSpec, Matchers}

class BuildCommonASTModelFromHTMLBindingModelSpec extends FunSpec with Matchers {

  describe("transform") {

    describe("for a model with a single binding") {

      it("should be built correctly") {
        HTMLBindingsToCommonASTTransformer.transform(List(HTMLBinding(Nil, "a", HTMLBindingString))) should equal(CommonASTTypeContainer(Map("a" -> CommonASTString)))
      }

    }

    describe("for a model with a single function binding") {

      it("should be built correctly") {
        HTMLBindingsToCommonASTTransformer.transform(List(HTMLBinding(Nil, "a", HTMLBindingFunction(HTMLBindingVoid)))) should equal(CommonASTTypeContainer(Map("a" -> CommonASTFunction(CommonASTVoid))))
      }

    }

    describe("for a model with multiple bindings") {

      describe("on a single level") {

        it("should be built correctly") {
          HTMLBindingsToCommonASTTransformer.transform(List(HTMLBinding(Nil, "a", HTMLBindingString), HTMLBinding(Nil, "b", HTMLBindingString))) should equal(CommonASTTypeContainer(Map("a" -> CommonASTString, "b" -> CommonASTString)))
        }

      }

      describe("on multiple levels") {

        it("should be built correctly") {

          val b = HTMLSimpleBindingContextName

          val model = HTMLBindingsToCommonASTTransformer.transform(List(
            HTMLBinding(Nil, "a", HTMLBindingString),
            HTMLBinding(b("b") :: b("c") :: Nil, "d", HTMLBindingString),
            HTMLBinding(b("b") :: b("c") :: Nil, "e", HTMLBindingString),
            HTMLBinding(b("b") :: b("f") :: Nil, "g", HTMLBindingString),
            HTMLBinding(b("h") :: b("i") :: b("j") :: Nil, "k", HTMLBindingString)))

          model should equal(CommonASTTypeContainer(Map(
            "a" -> CommonASTString,
            "b" -> CommonASTTypeContainer(Map(
              "c" -> CommonASTTypeContainer(Map(
                "d" -> CommonASTString,
                "e" -> CommonASTString)),
              "f" -> CommonASTTypeContainer(Map(
                "g" -> CommonASTString)))),
            "h" -> CommonASTTypeContainer(Map(
              "i" -> CommonASTTypeContainer(Map(
                "j" -> CommonASTTypeContainer(Map(
                  "k" -> CommonASTString)))))))))
        }

      }

    }

  }

}


