module testFiles.viewmodels {

  export interface IContactViewModel {
    contactIdentifier: string;
    personalName: PersonalName;
    allNames: PersonalName[];
    allFirstNames: string[];
    address: IAddress<string, number>;
    address2: IAddress<boolean, Date>;
  }

  export class PersonalName {
    firstName: string;
    lastName: string;
  }

  export interface IAddress<A, B> {
    addressLines: string[];
    thingA: A;
    thingB: B
  }

}