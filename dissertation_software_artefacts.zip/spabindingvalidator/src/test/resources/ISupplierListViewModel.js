var rb;
(function (rb) {
    var viewmodels;
    (function (viewmodels) {
        var SupplierListViewModel = (function () {
            function SupplierListViewModel() {
            }
            return SupplierListViewModel;
        })();
        viewmodels.SupplierListViewModel = SupplierListViewModel;
    })(viewmodels = rb.viewmodels || (rb.viewmodels = {}));
})(rb || (rb = {}));
