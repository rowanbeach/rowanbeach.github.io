module rb.suppliers {
    export interface ISupplierListItem {
        companyName : string;
    }
}

module rb.shared {

    export interface ICustomer<A, B> {
        thingA: A;
        thingB: B;
    }

    export interface IPagedList<T> {
        firstItem: T;
        items: T[];
        customer: ICustomer<string, T>;
    }
}

module rb.viewmodels {

    export class SupplierListViewModel {
         containerGenericProperty: rb.shared.IPagedList<rb.suppliers.ISupplierListItem>;
         primitiveGenericProperty: rb.shared.IPagedList<number>;
    }

}