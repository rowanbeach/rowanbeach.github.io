# Angular test project

## Pre-requisites

NodeJS and npm are required. They can be installed for a variety of operating systems from https://nodejs.org/

To install the grunt command line tool, run this from anywhere on your machine (this only needs to be installed once, if you already have it installed on your machine this step is unnecessary):
```
npm install -g grunt-cli
```

From the angular_test directory, run these commands
```
npm install
bower install
```

## To run

```
grunt serve
```

