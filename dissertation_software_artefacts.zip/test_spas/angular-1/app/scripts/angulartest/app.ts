// Library bits
/// <reference path='../../../typings/angularjs/angular.d.ts' />
/// <reference path='../../../typings/angular-ui/angular-ui-router.d.ts' />///

// Services
/// <reference path='logger.ts' />
/// <reference path='services/AuthorisationService.ts' />
/// <reference path='services/NotificationService.ts' />
/// <reference path='services/LoginService.ts' />

// Controllers
/// <reference path='controllers/MainController.ts' />
/// <reference path='controllers/AboutController.ts' />
/// <reference path='controllers/CustomerListController.ts' />

module angulartest.app {

    // TODO - split the various parts of this module configuration out into separate files
    angular
        .module('angular_test_app', ['ngAnimate', 'ngCookies', 'ngResource', 'ngRoute', 'ngSanitize', 'ngTouch', 'ui.router'])
        .config(($stateProvider:ng.ui.IStateProvider) => {

            // anonymous routes
            $stateProvider
                .state('anonymous', {abstract: true, template: '<ui-view></ui-view>', data: {requiredPermissions: permissions.Any}})
                .state('anonymous.login', {url: '/login', templateUrl: 'views/login.html', controller: controllers.LoginController});

            // authenticated routes
            $stateProvider
                .state('authenticated', {abstract: true, template: '<ui-view></ui-view>', data: {requiredPermissions: permissions.AnyAuthenticated}})
                .state('authenticated.index', {url: "", templateUrl: "views/main.html", controller: controllers.MainController})
                .state('authenticated.customerList', {url: "/customers", templateUrl: "views/customerList.html", controller: controllers.CustomerListController})
                .state('authenticated.about', {url: "/about", templateUrl: "views/about.html", controller: controllers.AboutController, data: {requiredPermissions: permissions.NamedPermission('about_viewer')}})
                .state('authenticated.contact', {url: "/contact", templateUrl: "views/contact.html", controller: controllers.ContactController});

        })
        .config(($httpProvider:ng.IHttpProvider) => {
            $httpProvider.defaults.withCredentials = true; // To allow cookies via CORS
        })
        .service('authorisationService', services.AuthorisationService)
        .service('notificationService', services.NotificationService)
        .service('loginService', services.LoginService)
        .service('customerSearchService', services.CustomerSearchService)
        .value('tokenStoreService', services.localStorageTokenStoreService)
        .run(($rootScope:ng.IRootScopeService, $state:ng.ui.IStateService, authorisationService:services.IAuthorisationService, notificationService:services.NotificationService) => {

            $rootScope.$on("$stateChangeStart", (event:ng.IAngularEvent, toState:ng.ui.IState, toParams, fromState:ng.ui.IState) => {

                log.info('state changing from ' + JSON.stringify(fromState) + ' to ' + JSON.stringify(toState));
                if (!toState.data || typeof(toState.data.requiredPermissions) === 'undefined') {
                    notificationService.error('Permissions not set state: ' + toState.name);
                    event.preventDefault();
                } else if (!authorisationService.authorise(toState.data.requiredPermissions)) {
                    log.info('Authorisation failed');
                    notificationService.error('You don\'t have access to this state: ' + toState.name);
                    event.preventDefault();

                    if (fromState.url === '^') {
                        if (authorisationService.authorise(permissions.AnyAuthenticated)) {
                            log.info('Request for root URL by authenticated user - changing state to authenticated.home');
                            $state.go('authenticated.home');
                        } else {
                            log.info('Request for root URL by anonymous user - changing state to anonymous.login');
                            $state.go('anonymous.login');
                        }
                    }

                }

            });

        });

}
