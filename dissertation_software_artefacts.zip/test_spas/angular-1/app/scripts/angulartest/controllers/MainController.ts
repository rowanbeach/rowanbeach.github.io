/// <reference path='IHasTypedViewModel.ts' />
/// <reference path='../viewmodels/IMainViewModel.ts' />

module angulartest.controllers {
  export class MainController {
    constructor($scope:IHasTypedViewModel<viewmodels.IMainViewModel>) {
      //$scope.viewmodel = {
      //  customerDates: [
      //    {time: new Date(), location: 'test', description: 'Some meeting'},
      //    {time: new Date(), location: 'Room 1', description: 'Some meeting'},
      //    {time: new Date(), location: 'Room 1', description: 'Some meeting'}
      //  ],
      //  currentExternalSession: null,
      //  externalSessionDates: [],
      //  currentSession: null,
      //  sessionDates: [],
      //  currentTotallyExternalSession: {nestedOtherRootTest: ''},
      //  doSomething: null
      //};
    }
  }
}
