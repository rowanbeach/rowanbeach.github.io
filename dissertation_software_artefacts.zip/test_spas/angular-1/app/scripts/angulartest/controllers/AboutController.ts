/// <reference path='IHasTypedViewModel.ts' />
/// <reference path='../viewmodels/IAboutViewModel.ts' />

module angulartest.controllers {

    export class AboutController {

        constructor($scope:IHasTypedViewModel<viewmodels.IAboutViewModel>) {

            $scope.viewmodel = {
                aboutList: [
                    {url: "This", text: "is"},
                    {url: "a", text: "test"}
                ],
                title: "About"
            };

        }
    }

}
