/// <reference path='IHasTypedViewModel.ts' />
/// <reference path='../viewmodels/IContactViewModel.ts' />

module angulartest.controllers {

    export class ContactController {

        constructor($scope:IHasTypedViewModel<viewmodels.IContactViewModel>) {
            $scope.viewmodel = {
                contactList: [
                    {url: "test1", text: "John Smith"},
                    {url: "test2", text: "Bob Jones"}
                ],
                selectedContact: {
                    contactIdentifier: '12345',
                    personalName: {firstName: "John", lastName: "Smith"},
                    address: null,
                    address2: null,
                    additionalAddress: null
                }
            };
        }
    }

}
