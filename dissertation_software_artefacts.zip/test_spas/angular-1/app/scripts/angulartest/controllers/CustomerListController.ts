///<reference path="IHasTypedViewModel.ts" />
///<reference path="../viewmodels/ICustomerListViewModel.ts" />
///<reference path="../services/CustomerSearchService.ts" />
///<reference path="../services/NotificationService.ts" />

module angulartest.controllers {

  export class CustomerListController {

    constructor($scope:IHasTypedViewModel<viewmodels.ICustomerListViewModel>, customerSearchService:services.ICustomerSearchService) {
      $scope.viewmodel = {customers: [], searchText: ''};

      customerSearchService.getCustomers().then(
        customers => {
          $scope.viewmodel.customers = customers.map(x => ({id: x.id, firstName: x.firstName, surname: x.surname}));
        }
      );
    }

  }

}

