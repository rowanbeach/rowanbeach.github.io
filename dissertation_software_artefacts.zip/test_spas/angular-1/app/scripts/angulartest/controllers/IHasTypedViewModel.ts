module angulartest.controllers {
  export interface IHasTypedViewModel<TViewModel> {
    viewmodel: TViewModel;
  }
}




