///<reference path="IHasTypedViewModel.ts" />
///<reference path="../viewmodels/ILoginViewModel.ts" />
///<reference path="../services/LoginService.ts" />
///<reference path="../services/NotificationService.ts"/>

module angulartest.controllers {

    export function LoginController($scope:IHasTypedViewModel<viewmodels.ILoginViewModel>, loginService:services.LoginService, notificationService:services.NotificationService, $state:ng.ui.IStateService) {

        $scope.viewmodel = {
            username: "test",
            password: "test",
            login: () => {
                log.info("logging in with username:" + $scope.viewmodel.username + " and password:" + $scope.viewmodel.password);
                if (loginService.login($scope.viewmodel.username, $scope.viewmodel.password)) {
                    notificationService.info("Logged in OK!");
                    $state.go("authenticated.index");
                } else {
                    notificationService.error("Incorrect credentials - try again!");
                }

            },
            logout: () => {
                loginService.logout();
                notificationService.info("Logged out!");
            }
        };

    }

}

