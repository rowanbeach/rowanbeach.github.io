module angulartest.permissions {

    export interface IPermissionDescriptor {
        requireAuthenticated: Boolean;
        permissionName: string;
    }

    export var Any:IPermissionDescriptor = {
        requireAuthenticated: false,
        permissionName: null
    };

    export var AnyAuthenticated:IPermissionDescriptor = {
        requireAuthenticated: true,
        permissionName: null
    };

    export function NamedPermission(permissionName:string):IPermissionDescriptor {
        return {
            requireAuthenticated: true,
            permissionName: permissionName
        }
    }

}
