module angulartest {
  export interface ICustomerListItemModel {
    id: string;
    firstName: string;
    surname: string;
  }
}
