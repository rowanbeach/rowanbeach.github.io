module angulartest {

  function _log(logLevel:LogLevel, message:string) {

    if (logLevel >= currentLogLevel) {
      if (logLevel >= 3)
        console.error('LOG: level: ' + LogLevel[logLevel] + '\n' + message);
      else
        console.log('LOG: level: ' + LogLevel[logLevel] + '\n' + message);
    }

  }

  export var log = {
    error: (message:string) => _log(LogLevel.error, message),
    warn: (message:string)  => _log(LogLevel.warn, message),
    info: (message:string) => _log(LogLevel.info, message),
    debug: (message:string) => _log(LogLevel.debug, message)
  };

  export enum LogLevel {
    error = 4,
    warn = 3,
    info = 2,
    debug = 1
  }

  export var currentLogLevel:LogLevel = LogLevel.info;

  export var setLogLevel = {
    error: () => currentLogLevel = LogLevel.error,
    warn: () => currentLogLevel = LogLevel.warn,
    info: () => currentLogLevel = LogLevel.info,
    debug: () => currentLogLevel = LogLevel.debug
  }

}


