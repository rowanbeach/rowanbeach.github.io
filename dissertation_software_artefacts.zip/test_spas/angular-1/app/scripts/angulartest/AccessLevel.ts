module angulartest {
  export enum AccessLevel {
    anonymous = 1,
    authenticated = 2
  }
}
