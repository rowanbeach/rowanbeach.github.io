module angulartest.viewmodels {
  export interface ICustomerListItem {
    id: string;
    firstName: string;
    surname: string;
  }

  export interface ICustomerListViewModel {
    customers: ICustomerListItem[];
    searchText: string;
  }

}

