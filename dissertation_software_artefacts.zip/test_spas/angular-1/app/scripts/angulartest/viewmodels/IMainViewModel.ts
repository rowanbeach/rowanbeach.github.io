/// <reference path='ExternalSessionViewModel.ts' />

module angulartest.viewmodels {

    export interface IParameterisedSession<T, U, V> {
        thingt: T;
        thingv: U;
        location: Location<T, V>;
    }

    export interface Location<A, B> {
        thinga: A;
        thingb: B;
    }

    export interface IMainViewModel {
        name: string;
        currentExternalSession: externalSessions.ISession;
        bottomCSSClassName: string;
        topCSSClassName: string;
        showIt: boolean;
        currentParameterisedSession: IParameterisedSession<string, number, string>;
    }

}
