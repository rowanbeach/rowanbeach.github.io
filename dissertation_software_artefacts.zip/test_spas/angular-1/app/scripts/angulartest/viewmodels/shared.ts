module angulartest.viewmodels {
    export interface IDisplayItem {
        url: string;
        text: string;
    }
}