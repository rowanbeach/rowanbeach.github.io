var angulartest;
(function (angulartest) {
    (function (viewmodels) {
        var PersonalName = (function () {
            function PersonalName() {
            }
            return PersonalName;
        })();
        viewmodels.PersonalName = PersonalName;
    })(angulartest.viewmodels || (angulartest.viewmodels = {}));
    var viewmodels = angulartest.viewmodels;
})(angulartest || (angulartest = {}));
