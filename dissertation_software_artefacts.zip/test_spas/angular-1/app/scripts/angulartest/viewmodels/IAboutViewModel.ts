/// <reference path="shared.ts"/>

module angulartest.viewmodels {
  export interface IAboutViewModel {
    aboutList: IDisplayItem[];
    title: string;
  }
}
