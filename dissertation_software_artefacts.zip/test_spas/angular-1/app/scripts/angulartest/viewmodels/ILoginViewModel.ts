module angulartest.viewmodels {
  export interface ILoginViewModel {
    username:string;
    password:string;
    login: () => void
    logout: () => void
  }
}

