module angulartest.services {

  export enum NotificationLevel {
    error = 4,
    warn = 3,
    info = 2,
    debug = 1
  }

}
