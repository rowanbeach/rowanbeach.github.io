///<reference path="../../../../typings/angularjs/angular.d.ts"/>
///<reference path="NotificationService.ts"/>

module angulartest.services {

    export interface IToken {
        username: String;
        permissions: String [];
    }

    export interface ITokenStoreService {
        getToken() : IToken;
        clearToken() : void;
        setToken(token:IToken);
    }

    var AUTH_TOKEN_KEY = '_ct4_auth_token';

    export var localStorageTokenStoreService = {
        getToken: () => {
            var json = window.localStorage.getItem(AUTH_TOKEN_KEY);
            return json ? JSON.parse(json) : null;
        },
        clearToken: () => window.localStorage.clear(),
        setToken: (token:IToken) => window.localStorage.setItem(AUTH_TOKEN_KEY, JSON.stringify(token))
    };

    export class LoginService {

        constructor(private tokenStoreService:ITokenStoreService) { }

        login(username:String, password:String):boolean {

            if (username === "test" && password === "test") {
                this.tokenStoreService.setToken({username: username, permissions: ['about_viewer', 'view_customer']});
                return true;
            } else {
                this.tokenStoreService.clearToken();
                return false;
            }

        }

        logout() {
            log.info('logging out...');
            this.tokenStoreService.clearToken();
        }

    }

    // Check whether GSTT can send outcustomer appointment outcomes in HL7 messages
    // Call transfer of PDF

}
