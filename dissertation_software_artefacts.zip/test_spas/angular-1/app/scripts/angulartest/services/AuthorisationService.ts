///<reference path="../PermissionDescriptor.ts"/>

module angulartest.services {

  export interface IAuthorisationService {
    authorise(permissionDescriptor:permissions.IPermissionDescriptor)
  }

  function authInternal(permissionDescriptor:permissions.IPermissionDescriptor, tokenStoreService : ITokenStoreService):Boolean {
    if (!permissionDescriptor.requireAuthenticated) return true;

    var token = tokenStoreService.getToken();
    if (token == null) return false;

    if (!permissionDescriptor.permissionName) return true;

    return token.permissions.indexOf(permissionDescriptor.permissionName) >= 0;

  }

  export class AuthorisationService implements IAuthorisationService {

    constructor(private tokenStoreService:ITokenStoreService) {}

    authorise(permissionDescriptor:permissions.IPermissionDescriptor):Boolean {
      var result = authInternal(permissionDescriptor, this.tokenStoreService); // This separate internal call is just used so we can easily log the result
      log.info('AuthorisationService.authorise -> : permissionDescriptor' + JSON.stringify(permissionDescriptor) + ', result: ' + result);
      return result;
    }

  }

}
