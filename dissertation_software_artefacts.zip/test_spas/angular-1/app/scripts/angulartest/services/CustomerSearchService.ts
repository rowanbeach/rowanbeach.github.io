///<reference path="../models/ICustomerListItemModel.ts" />

module angulartest.services {

  export interface ICustomerSearchService {
    getCustomers(): ng.IPromise<ICustomerListItemModel[]>;
  }

  export class CustomerSearchService implements ICustomerSearchService {

    constructor(private $http:ng.IHttpService) {}

    getCustomers() {
      return this
        .$http
        .get<ICustomerListItemModel[]>('http://localhost:9292/ot-uk-systest-cprm.havaslynx.com/api/nancy/customers/search/?archive=false')
        .then(x => x.data);
    }

  }
}
