/// <reference path="NotificationLevel" />

module angulartest.services {

  export class NotificationService {

    notify(notificationLevel:NotificationLevel, message:string) {
      log.info('TEMP - in the absence of UI, logging a NOTIFICATION in the console: ' + NotificationLevel[notificationLevel] + '\n' + message);
    }

    error(message:string) {
      this.notify(NotificationLevel.error, message);
      window.alert("ERROR:" + message);
    }

    warn(message:string) {
      this.notify(NotificationLevel.warn, message);
      window.alert(message);
    }

    info(message:string) {
      this.notify(NotificationLevel.info, message);
      window.alert(message);
    }

    debug(message:string) {
      this.notify(NotificationLevel.debug, message);
    }

  }

}

