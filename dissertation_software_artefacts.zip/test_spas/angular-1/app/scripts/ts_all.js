var angulartest;
(function (angulartest) {
    function _log(logLevel, message) {
        if (logLevel >= angulartest.currentLogLevel) {
            if (logLevel >= 3)
                console.error('LOG: level: ' + LogLevel[logLevel] + '\n' + message);
            else
                console.log('LOG: level: ' + LogLevel[logLevel] + '\n' + message);
        }
    }

    angulartest.log = {
        error: function (message) {
            return _log(4 /* error */, message);
        },
        warn: function (message) {
            return _log(3 /* warn */, message);
        },
        info: function (message) {
            return _log(2 /* info */, message);
        },
        debug: function (message) {
            return _log(1 /* debug */, message);
        }
    };

    (function (LogLevel) {
        LogLevel[LogLevel["error"] = 4] = "error";
        LogLevel[LogLevel["warn"] = 3] = "warn";
        LogLevel[LogLevel["info"] = 2] = "info";
        LogLevel[LogLevel["debug"] = 1] = "debug";
    })(angulartest.LogLevel || (angulartest.LogLevel = {}));
    var LogLevel = angulartest.LogLevel;

    angulartest.currentLogLevel = 2 /* info */;

    angulartest.setLogLevel = {
        error: function () {
            return angulartest.currentLogLevel = 4 /* error */;
        },
        warn: function () {
            return angulartest.currentLogLevel = 3 /* warn */;
        },
        info: function () {
            return angulartest.currentLogLevel = 2 /* info */;
        },
        debug: function () {
            return angulartest.currentLogLevel = 1 /* debug */;
        }
    };
})(angulartest || (angulartest = {}));
var angulartest;
(function (angulartest) {
    (function (permissions) {
        permissions.Any = {
            requireAuthenticated: false,
            permissionName: null
        };

        permissions.AnyAuthenticated = {
            requireAuthenticated: true,
            permissionName: null
        };

        function NamedPermission(permissionName) {
            return {
                requireAuthenticated: true,
                permissionName: permissionName
            };
        }
        permissions.NamedPermission = NamedPermission;
    })(angulartest.permissions || (angulartest.permissions = {}));
    var permissions = angulartest.permissions;
})(angulartest || (angulartest = {}));
var angulartest;
(function (angulartest) {
    (function (services) {
        function authInternal(permissionDescriptor, tokenStoreService) {
            if (!permissionDescriptor.requireAuthenticated)
                return true;

            var token = tokenStoreService.getToken();
            if (token == null)
                return false;

            if (!permissionDescriptor.permissionName)
                return true;

            return token.permissions.indexOf(permissionDescriptor.permissionName) >= 0;
        }

        var AuthorisationService = (function () {
            function AuthorisationService(tokenStoreService) {
                this.tokenStoreService = tokenStoreService;
            }
            AuthorisationService.prototype.authorise = function (permissionDescriptor) {
                var result = authInternal(permissionDescriptor, this.tokenStoreService);
                angulartest.log.info('AuthorisationService.authorise -> : permissionDescriptor' + JSON.stringify(permissionDescriptor) + ', result: ' + result);
                return result;
            };
            return AuthorisationService;
        })();
        services.AuthorisationService = AuthorisationService;
    })(angulartest.services || (angulartest.services = {}));
    var services = angulartest.services;
})(angulartest || (angulartest = {}));
var angulartest;
(function (angulartest) {
    (function (services) {
        (function (NotificationLevel) {
            NotificationLevel[NotificationLevel["error"] = 4] = "error";
            NotificationLevel[NotificationLevel["warn"] = 3] = "warn";
            NotificationLevel[NotificationLevel["info"] = 2] = "info";
            NotificationLevel[NotificationLevel["debug"] = 1] = "debug";
        })(services.NotificationLevel || (services.NotificationLevel = {}));
        var NotificationLevel = services.NotificationLevel;
    })(angulartest.services || (angulartest.services = {}));
    var services = angulartest.services;
})(angulartest || (angulartest = {}));
var angulartest;
(function (angulartest) {
    (function (services) {
        var NotificationService = (function () {
            function NotificationService() {
            }
            NotificationService.prototype.notify = function (notificationLevel, message) {
                angulartest.log.info('TEMP - in the absence of UI, logging a NOTIFICATION in the console: ' + services.NotificationLevel[notificationLevel] + '\n' + message);
            };

            NotificationService.prototype.error = function (message) {
                this.notify(4 /* error */, message);
                window.alert("ERROR:" + message);
            };

            NotificationService.prototype.warn = function (message) {
                this.notify(3 /* warn */, message);
                window.alert(message);
            };

            NotificationService.prototype.info = function (message) {
                this.notify(2 /* info */, message);
                window.alert(message);
            };

            NotificationService.prototype.debug = function (message) {
                this.notify(1 /* debug */, message);
            };
            return NotificationService;
        })();
        services.NotificationService = NotificationService;
    })(angulartest.services || (angulartest.services = {}));
    var services = angulartest.services;
})(angulartest || (angulartest = {}));
var angulartest;
(function (angulartest) {
    (function (services) {
        var AUTH_TOKEN_KEY = '_ct4_auth_token';

        services.localStorageTokenStoreService = {
            getToken: function () {
                var json = window.localStorage.getItem(AUTH_TOKEN_KEY);
                return json ? JSON.parse(json) : null;
            },
            clearToken: function () {
                return window.localStorage.clear();
            },
            setToken: function (token) {
                return window.localStorage.setItem(AUTH_TOKEN_KEY, JSON.stringify(token));
            }
        };

        var LoginService = (function () {
            function LoginService(tokenStoreService) {
                this.tokenStoreService = tokenStoreService;
            }
            LoginService.prototype.login = function (username, password) {
                if (username === "test" && password === "test") {
                    this.tokenStoreService.setToken({ username: username, permissions: ['about_viewer', 'view_customer'] });
                    return true;
                } else {
                    this.tokenStoreService.clearToken();
                    return false;
                }
            };

            LoginService.prototype.logout = function () {
                angulartest.log.info('logging out...');
                this.tokenStoreService.clearToken();
            };
            return LoginService;
        })();
        services.LoginService = LoginService;
    })(angulartest.services || (angulartest.services = {}));
    var services = angulartest.services;
})(angulartest || (angulartest = {}));
var angulartest;
(function (angulartest) {
    (function (controllers) {
        var MainController = (function () {
            function MainController($scope) {
            }
            return MainController;
        })();
        controllers.MainController = MainController;
    })(angulartest.controllers || (angulartest.controllers = {}));
    var controllers = angulartest.controllers;
})(angulartest || (angulartest = {}));
var angulartest;
(function (angulartest) {
    (function (controllers) {
        var AboutController = (function () {
            function AboutController($scope) {
                $scope.viewmodel = {
                    aboutList: [
                        { url: "This", text: "is" },
                        { url: "a", text: "test" }
                    ],
                    title: "About"
                };
            }
            return AboutController;
        })();
        controllers.AboutController = AboutController;
    })(angulartest.controllers || (angulartest.controllers = {}));
    var controllers = angulartest.controllers;
})(angulartest || (angulartest = {}));
var angulartest;
(function (angulartest) {
    (function (services) {
        var CustomerSearchService = (function () {
            function CustomerSearchService($http) {
                this.$http = $http;
            }
            CustomerSearchService.prototype.getCustomers = function () {
                return this.$http.get('http://localhost:9292/ot-uk-systest-cprm.havaslynx.com/api/nancy/customers/search/?archive=false').then(function (x) {
                    return x.data;
                });
            };
            return CustomerSearchService;
        })();
        services.CustomerSearchService = CustomerSearchService;
    })(angulartest.services || (angulartest.services = {}));
    var services = angulartest.services;
})(angulartest || (angulartest = {}));
var angulartest;
(function (angulartest) {
    (function (controllers) {
        var CustomerListController = (function () {
            function CustomerListController($scope, customerSearchService) {
                $scope.viewmodel = { customers: [], searchText: '' };

                customerSearchService.getCustomers().then(function (customers) {
                    $scope.viewmodel.customers = customers.map(function (x) {
                        return ({ id: x.id, firstName: x.firstName, surname: x.surname });
                    });
                });
            }
            return CustomerListController;
        })();
        controllers.CustomerListController = CustomerListController;
    })(angulartest.controllers || (angulartest.controllers = {}));
    var controllers = angulartest.controllers;
})(angulartest || (angulartest = {}));
var angulartest;
(function (angulartest) {
    (function (app) {
        angular.module('angular_test_app', ['ngAnimate', 'ngCookies', 'ngResource', 'ngRoute', 'ngSanitize', 'ngTouch', 'ui.router']).config(function ($stateProvider) {
            $stateProvider.state('anonymous', { abstract: true, template: '<ui-view></ui-view>', data: { requiredPermissions: angulartest.permissions.Any } }).state('anonymous.login', { url: '/login', templateUrl: 'views/login.html', controller: angulartest.controllers.LoginController });

            $stateProvider.state('authenticated', { abstract: true, template: '<ui-view></ui-view>', data: { requiredPermissions: angulartest.permissions.AnyAuthenticated } }).state('authenticated.index', { url: "", templateUrl: "views/main.html", controller: angulartest.controllers.MainController }).state('authenticated.customerList', { url: "/customers", templateUrl: "views/customerList.html", controller: angulartest.controllers.CustomerListController }).state('authenticated.about', { url: "/about", templateUrl: "views/about.html", controller: angulartest.controllers.AboutController, data: { requiredPermissions: angulartest.permissions.NamedPermission('about_viewer') } }).state('authenticated.contact', { url: "/contact", templateUrl: "views/contact.html", controller: angulartest.controllers.ContactController });
        }).config(function ($httpProvider) {
            $httpProvider.defaults.withCredentials = true;
        }).service('authorisationService', angulartest.services.AuthorisationService).service('notificationService', angulartest.services.NotificationService).service('loginService', angulartest.services.LoginService).service('customerSearchService', angulartest.services.CustomerSearchService).value('tokenStoreService', angulartest.services.localStorageTokenStoreService).run(function ($rootScope, $state, authorisationService, notificationService) {
            $rootScope.$on("$stateChangeStart", function (event, toState, toParams, fromState) {
                angulartest.log.info('state changing from ' + JSON.stringify(fromState) + ' to ' + JSON.stringify(toState));
                if (!toState.data || typeof (toState.data.requiredPermissions) === 'undefined') {
                    notificationService.error('Permissions not set state: ' + toState.name);
                    event.preventDefault();
                } else if (!authorisationService.authorise(toState.data.requiredPermissions)) {
                    angulartest.log.info('Authorisation failed');
                    notificationService.error('You don\'t have access to this state: ' + toState.name);
                    event.preventDefault();

                    if (fromState.url === '^') {
                        if (authorisationService.authorise(angulartest.permissions.AnyAuthenticated)) {
                            angulartest.log.info('Request for root URL by authenticated user - changing state to authenticated.home');
                            $state.go('authenticated.home');
                        } else {
                            angulartest.log.info('Request for root URL by anonymous user - changing state to anonymous.login');
                            $state.go('anonymous.login');
                        }
                    }
                }
            });
        });
    })(angulartest.app || (angulartest.app = {}));
    var app = angulartest.app;
})(angulartest || (angulartest = {}));
var angulartest;
(function (angulartest) {
    (function (viewmodels) {
        var PersonalName = (function () {
            function PersonalName() {
            }
            return PersonalName;
        })();
        viewmodels.PersonalName = PersonalName;
    })(angulartest.viewmodels || (angulartest.viewmodels = {}));
    var viewmodels = angulartest.viewmodels;
})(angulartest || (angulartest = {}));
var angulartest;
(function (angulartest) {
    (function (controllers) {
        var ContactController = (function () {
            function ContactController($scope) {
                $scope.viewmodel = {
                    contactList: [
                        { url: "test1", text: "John Smith" },
                        { url: "test2", text: "Bob Jones" }
                    ],
                    selectedContact: {
                        contactIdentifier: '12345',
                        personalName: { firstName: "John", lastName: "Smith" },
                        address: null,
                        address2: null,
                        additionalAddress: null
                    }
                };
            }
            return ContactController;
        })();
        controllers.ContactController = ContactController;
    })(angulartest.controllers || (angulartest.controllers = {}));
    var controllers = angulartest.controllers;
})(angulartest || (angulartest = {}));
var angulartest;
(function (angulartest) {
    (function (controllers) {
        function LoginController($scope, loginService, notificationService, $state) {
            $scope.viewmodel = {
                username: "test",
                password: "test",
                login: function () {
                    angulartest.log.info("logging in with username:" + $scope.viewmodel.username + " and password:" + $scope.viewmodel.password);
                    if (loginService.login($scope.viewmodel.username, $scope.viewmodel.password)) {
                        notificationService.info("Logged in OK!");
                        $state.go("authenticated.index");
                    } else {
                        notificationService.error("Incorrect credentials - try again!");
                    }
                },
                logout: function () {
                    loginService.logout();
                    notificationService.info("Logged out!");
                }
            };
        }
        controllers.LoginController = LoginController;
    })(angulartest.controllers || (angulartest.controllers = {}));
    var controllers = angulartest.controllers;
})(angulartest || (angulartest = {}));
//# sourceMappingURL=ts_all.js.map
