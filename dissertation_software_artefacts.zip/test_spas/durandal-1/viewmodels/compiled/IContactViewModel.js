var durandaltest;
(function (durandaltest) {
    (function (viewmodels) {
        var PersonalName = (function () {
            function PersonalName() {
            }
            return PersonalName;
        })();
        viewmodels.PersonalName = PersonalName;
    })(durandaltest.viewmodels || (durandaltest.viewmodels = {}));
    var viewmodels = durandaltest.viewmodels;
})(durandaltest || (durandaltest = {}));
