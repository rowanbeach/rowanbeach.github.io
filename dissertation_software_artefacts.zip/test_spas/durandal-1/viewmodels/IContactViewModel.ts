/// <reference path="../typings/knockout/knockout.d.ts" />
///<reference path="shared.ts"/>

module durandaltest.viewmodels {

    export interface IContactViewModel {
        contactList: IDisplayItem[];
        selectedContact: ISelectedContact;
    }

    export interface ISelectedContact {
        contactIdentifier: string;
        personalName: PersonalName;
        address: IAugmentedAddress<string, number>;
        additionalAddress: IAugmentedAddress<boolean, string>;
    }

    export class PersonalName {
        firstName:string;
        lastName:string;
    }

    export interface IAugmentedAddress<A, B> {
        addressLine1: string;
        augmentationField1: A;
        augmentationField2: B
    }

}