/// <reference path="shared.ts"/>

module durandaltest.viewmodels {
    export interface IAboutViewModel {
        aboutList: IDisplayItem[];
        title: string;
    }
}
