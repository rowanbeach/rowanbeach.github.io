/// <reference path="../typings/knockout/knockout.d.ts" />

module durandaltest.viewmodels {
    export interface ILoginViewModel {
        username:KnockoutObservable<string>;
        password:string;
        login: () => void
        logout: () => void
    }
}
