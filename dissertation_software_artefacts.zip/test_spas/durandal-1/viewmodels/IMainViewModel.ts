/// <reference path="../typings/knockout/knockout.d.ts" />
/// <reference path='ExternalSessionViewModel.ts' />

module durandaltest.viewmodels {

    export interface IParameterisedSession<T, U, V> {
        thingt: T;
        thingv: U;
        location: Location<T, V>;
    }

    export interface Location<A, B> {
        thinga: A;
        thingb: B;
    }

    export interface IMainViewModel {
        name: KnockoutObservable<string>;
        currentExternalSession: externalSessions.ISession;
        bottomCSSClassName: string;
        topCSSClassName: string;
        showIt: boolean;
        currentParameterisedSession: IParameterisedSession<string, number, string>;
    }

}
