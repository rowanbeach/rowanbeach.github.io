module durandaltest.viewmodels {
    export interface IDisplayItem {
        url: string;
        text: string;
    }
}