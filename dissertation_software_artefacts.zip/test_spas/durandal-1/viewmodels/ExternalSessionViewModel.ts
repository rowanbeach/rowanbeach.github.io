module durandaltest.externalSessions {

    export interface IRoomType {
        roomTypeDescription: string;
    }

    export interface ISession {
        innerRoom1: IRoomType;
        externalRoom: string;
    }

}
