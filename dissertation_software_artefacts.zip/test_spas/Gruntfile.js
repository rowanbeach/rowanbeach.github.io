'use strict';

module.exports = function (grunt) {

    grunt.loadNpmTasks('grunt-typescript');

    grunt.initConfig({

        typescript: {
            'angular-1': {
                src: ['angular-1/app/scripts/angulartest/viewmodels/**/*ViewModel.ts'],
                dest: 'angular-1/app/scripts/angulartest/viewmodels/compiled',
                options: {
                    module: 'amd',
                    basePath: 'angular-1/app/scripts/angulartest/viewmodels'
                }
            },
            'angular-2': {
                src: ['angular-2/viewmodels/**/*ViewModel.ts'],
                dest: 'angular-2/viewmodels/compiled',
                options: {
                    module: 'amd',
                    basePath: 'angular-2/viewmodels'
                }
            },
            'durandal-1': {
                src: ['durandal-1/viewmodels/**/*ViewModel.ts'],
                dest: 'durandal-1/viewmodels/compiled',
                options: {
                    module: 'amd',
                    basePath: 'durandal-1/viewmodels'
                }
            },
            'durandal-2': {
                src: ['durandal-1/viewmodels/**/*ViewModel.ts'],
                dest: 'durandal-1/viewmodels/compiled',
                options: {
                    module: 'amd',
                    basePath: 'durandal-1/viewmodels'
                }
            }
        }

    });

    grunt.registerTask('default', [
        'typescript'
    ]);

};
