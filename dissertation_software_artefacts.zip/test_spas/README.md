# Test SPAs for dissertation project

angular-1 is a functional application which can be run in a browser. The other systems are simply collections of html views and typescript viewmodels which are set up to serve as test cases for various scenarios.
   
The typescript viewmodels for all applications except for angular-1 can be compiled by running the grunt tasks which are set for this purpose. While compiling them in this way is not required to run the tests, it can be useful to prove that the typescript code is valid (or not) when making changes. 

## Pre-requisites

NodeJS and npm are required. They can be installed for a variety of operating systems from https://nodejs.org/

To install the grunt command line tool, run this from anywhere on your machine (this only needs to be installed once, if you already have it installed on your machine this step is unnecessary):
```
npm install -g grunt-cli
```

From the test_spas directory, run this command
```
npm install
```

## To compile all of the typescript view model files

```
grunt
```

Note that this will compile the view model files for angular-1 rather than the full angular-1 application. To compile the full application run grunt:typescript inside the angular-1 directory. 

## To compile a specific set of typescript files
```
grunt typescript:angular-2
```

See the README.md file in the angular-1 subdirectory for instructions about compiling and running that application.
